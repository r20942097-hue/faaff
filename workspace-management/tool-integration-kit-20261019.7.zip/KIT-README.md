# 取得元診断・一時ログを作らない回収の導入キット 20261019.7

48ファイルのv8開発候補です。管理19機能・標準20検査を登録し、取得元・差分診断を追加します。本体未取得9製品は含みません。以前の固定ZIPは保持しています。

キットZIPの外部SHA256を照合して新しい場所へ展開し、その場所で実行します。94c673e12299a93e018c4618155dade3c82378db36f0c35141ca3cb06944cd94を同梱更新ZIPの照合値に置き換えてください。

```sh
python apply_catalogue_update.py --base workspace-source-20261011.zip --update catalogue-update-20261019.7.zip --update-sha256 94c673e12299a93e018c4618155dade3c82378db36f0c35141ca3cb06944cd94 --output work/integrated-tools
```

基準ZIPと更新全48ファイルのパス・SHA256を照合します。既存の作業先は上書きしません。作成されたwork/integrated-toolsへ移動し、新しい仮想環境を作成します。

```sh
python -m venv work/verify-env
```

Linuxでは `work/verify-env/bin/python`、Windowsでは `work/verify-env/Scripts/python.exe` で、次のpythonを置き換えます。

```sh
python tools/manage.py setup
python tools/manage.py doctor
python tools/manage.py all --workflows
python tools/manage.py run --tool module-search
python tools/manage.py run --tool suite-audit
python tools/manage.py portfolio
python tools/manage.py check
python tools/source_provenance.py --root . --baseline ../../workspace-source-20261011.zip --baseline-sha256 e2ab70a46e41a2f193f8738b0917a9966c3850056f68d79e0f7b48b3e59208d9 --update ../../catalogue-update-20261019.7.zip --update-sha256 94c673e12299a93e018c4618155dade3c82378db36f0c35141ca3cb06944cd94 --output work/provenance-20261019
```

setupは固定版・SHA256を照合して依存を導入します。成果物一覧はcatalog/generated/artifacts.html、製品別予定はcatalog/PORTFOLIO.md、取得元と差分はwork/provenance-20261019/index.htmlで確認できます。ZIP内の成果物一覧48件は作成時の記録で、この候補2件を追加した外部一覧は50件です。

出力回収は一時ログファイルを作らず、stdout/stderrの先頭を各2MiBまで保持します。上限超過後も中断猶予中は読み捨てて監督プロセスの後始末を進めます。超過125、時間切れ124、中断130と部分ログを残します。バイト数は回収した観測値です。対象自身の保存ファイルや管轄外プロセスまで容量・停止を保証するものではありません。

取得元診断は固定基準・指定更新・現在のファイルを照合し、設定に記録された参照先・SHA256・履歴を分けます。GitHubへの通信照合、対象コードの実行、製品E2Eは行いません。

基準ZIPの実内容は20261012.2、互換名はworkspace-source-20261011.zipです。広告フィルターの本文・版・購読URLは変更していません。既存の推奨選択は維持し、今回の候補を自動昇格しません。

連続中断で終了メッセージや結果記録が中断される条件を修正しました。最初の中断後は結果と後始末が完了するまで追加の中断の再入を抑え、呼出し元の独自SIGINTハンドラーは維持します。20261019.5以前の固定ZIPは履歴として保持します。

ハンドラー登録直後の中断でも復元処理が呼ばれるよう、登録前に復元を予約します。メインスレッド以外で登録できない場合は、未登録のハンドラーを復元しようとしません。
