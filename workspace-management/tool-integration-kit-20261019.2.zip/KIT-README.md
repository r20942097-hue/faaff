# 成果物管理と実行診断の導入キット 20261019.2

42ファイルのv6開発候補です。管理19機能・標準20検査を登録します。未取得9製品の本体は含まれません。

キットZIPの外部SHA256を照合して新しい場所へ展開し、その場所で次を実行します。c560bb5ccb4290c89d18f36b8743eb4a11f8c0ccb67e1bd945272127d38c5887は同梱更新ZIPの外部照合値へ置き換えます。

```sh
python apply_catalogue_update.py --base workspace-source-20261011.zip --update catalogue-update-20261019.2.zip --update-sha256 c560bb5ccb4290c89d18f36b8743eb4a11f8c0ccb67e1bd945272127d38c5887 --output work/integrated-tools
```

固定基準ZIPのSHA256と、更新全42ファイルのパス・SHA256を照合して新規ディレクトリだけに適用します。既存の作業先は上書きしません。

作成されたwork/integrated-toolsへ移動し、新しい仮想環境を作成します。

```sh
python -m venv work/verify-env
```

Linuxでは `work/verify-env/bin/python`、Windowsでは `work/verify-env/Scripts/python.exe` で、次のpythonを置き換えます。

```sh
python tools/manage.py setup
python tools/manage.py doctor
python tools/manage.py all --workflows
python tools/manage.py run --tool module-search
python tools/manage.py portfolio
python tools/manage.py check
```

setupは固定版・SHA256を照合して検証依存を導入します。成果物一覧は `catalog/generated/artifacts.html`、製品別の継続開発は `catalog/PORTFOLIO.md` を参照してください。ZIP内の成果物一覧38件は作成時の記録で、この候補2件を追加した外部一覧は40件です。

追加変更：

- CRLF・CR・LFのメタデータを行単位で扱い、空欄から次のヘッダーを取り込まないようにしました。20261019.1のWindows CI失敗を修正する候補です。
- 共通の通常実行はstdout/stderrを各2MiBまで保持し、超過を終了コード125、時間切れを124、中断を130として部分ログを残します。POSIXプロセス群・Windows Jobの所有範囲を停止します。明示的interrupt_grace経路は以前の実装です。
- モジュール検索は同じPython起動オプション・cwd・環境で標準PathFinderの結果を観測します。対象パッケージの初期化と入口コードは実行せず、外部検索パスはハッシュ化します。対象コードの実行時importの証明ではありません。

出力は一時ファイルへ書き出し、監視間隔内には上限を超える場合があります。ディスクの瞬間的な利用量、切り離されたPOSIXセッション、外部デーモン、制御側のSIGKILLは保証範囲外です。

Python起動時フック・カスタムimport finder・親パッケージによる__path__変更・同時編集・間接依存の実行時検索先は未検証です。登録入力が観測中に変わった場合、診断は合格にしません。全製品のE2Eや動画録画受入は別途必要です。
