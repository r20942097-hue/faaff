# 成果物管理と実行診断の導入キット 20261019.3

43ファイルのv7開発候補です。管理19機能・標準20検査を登録します。未取得9製品の本体は含まれません。

キットZIPの外部SHA256を照合して新しい場所へ展開し、その場所で次を実行します。8b353d3f7db365a08d0ebaa972530aa36716b369b709502cccf6b2c4a7e2eb25は同梱更新ZIPの外部照合値へ置き換えます。

```sh
python apply_catalogue_update.py --base workspace-source-20261011.zip --update catalogue-update-20261019.3.zip --update-sha256 8b353d3f7db365a08d0ebaa972530aa36716b369b709502cccf6b2c4a7e2eb25 --output work/integrated-tools
```

固定基準ZIPのSHA256と、更新全43ファイルのパス・SHA256を照合して新規ディレクトリだけに適用します。既存の作業先は上書きしません。

作成されたwork/integrated-toolsへ移動し、新しい仮想環境を作成します。

```sh
python -m venv work/verify-env
```

Linuxでは `work/verify-env/bin/python`、Windowsでは `work/verify-env/Scripts/python.exe` で、次のpythonを置き換えます。

```sh
python tools/manage.py setup
python tools/manage.py doctor
python tools/manage.py all --workflows
python tools/manage.py run --tool module-search
python tools/manage.py portfolio
python tools/manage.py check
```

setupは固定版・SHA256を照合して検証依存を導入します。成果物一覧は `catalog/generated/artifacts.html`、製品別の継続開発は `catalog/PORTFOLIO.md` を参照してください。ZIP内の成果物一覧40件は作成時の記録で、この候補2件を追加した外部一覧は40件です。

追加変更：

- CRLF・CR・LFのメタデータを行単位で扱い、空欄から次のヘッダーを取り込まないようにしました。20261019.1のWindows CI失敗を修正する候補です。
- 共通の通常実行と中断猶予付き実行はstdout/stderrを各2MiBまで保持し、超過を終了コード125、時間切れを124、中断を130として部分ログを残します。POSIXプロセス群・Windows Jobの所有範囲を停止します。明示的interrupt_grace経路も同じ保持上限を適用し、子の監督処理による後始末の猶予を確保します。
- モジュール検索は同じPython起動オプション・cwd・環境で標準PathFinderの結果を観測します。対象パッケージの初期化と入口コードは実行せず、外部検索パスはハッシュ化します。対象コードの実行時importの証明ではありません。

出力は一時ファイルへ書き出し、監視間隔内には上限を超える場合があります。ディスクの瞬間的な利用量、切り離されたPOSIXセッション、外部デーモン、制御側のSIGKILLは保証範囲外です。

Python起動時フック・カスタムimport finder・親パッケージによる__path__変更・同時編集・間接依存の実行時検索先は未検証です。登録入力が観測中に変わった場合、診断は合格にしません。全製品のE2Eや動画録画受入は別途必要です。

今回の追加修正では、Windowsの起動失敗にも対象実行ファイル名を記録します。画面検証はPlaywrightの読込み・ブラウザー起動より前に古い合格を無効化します。生成ルールのパスにある改行・制御文字、UTF-8へ出力できない単独サロゲートと255文字を超えるファイル名要素を拒否します。

中断猶予中は子の監督処理が自身のワーカーを停止できるよう、最大10秒の猶予内で一時ファイルへの書込みを継続します。最終的に保持するログは各ストリーム2MiB以内です。猶予内に終了できなければcontroller_forcedを記録して所有範囲を強制停止します。切り離されたPOSIXセッション等の範囲外は引き続き保証しません。
