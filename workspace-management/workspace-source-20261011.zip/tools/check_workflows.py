"""Optional local workflow policy checks (requires PyYAML)."""
import json
from pathlib import Path
import re
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]


class UniqueLoader(yaml.BaseLoader):
    pass


def unique_mapping(loader, node):
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node)
        if not isinstance(key, str):
            raise ValueError('YAML mapping keys must be scalar strings')
        if key in result:
            raise ValueError(f'duplicate YAML key: {key}')
        result[key] = loader.construct_object(value_node)
    return result


UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_mapping)


def validate(path):
    errors = []
    data = yaml.load(path.read_text(encoding='utf-8'), Loader=UniqueLoader)
    if not isinstance(data, dict) or not isinstance(data.get('jobs'), dict) or not data['jobs']:
        return ['missing jobs mapping']
    permissions = data.get('permissions', {})
    if not isinstance(permissions, dict) or permissions.get('contents') != 'read':
        errors.append('default contents permission must be a mapping with contents: read')
    action_pattern = r'[A-Za-z0-9_./-]+@[0-9a-f]{40}'
    for name, job in data['jobs'].items():
        if not isinstance(job, dict):
            errors.append(f'{name}: job must be a mapping')
            continue
        timeout = job.get('timeout-minutes', '')
        if not isinstance(timeout, str) or not timeout.isdigit() or not 1 <= int(timeout) <= 30:
            errors.append(f'{name}: missing or excessive job timeout')
        reused = job.get('uses')
        if reused is not None and (not isinstance(reused, str) or not re.fullmatch(action_pattern, reused)):
            errors.append(f'{name}: reusable workflow must use a full commit SHA')
        steps = job.get('steps', [])
        if not isinstance(steps, list):
            errors.append(f'{name}: steps must be a list')
            continue
        for index, step in enumerate(steps):
            if not isinstance(step, dict):
                errors.append(f'{name}: step {index + 1} must be a mapping')
                continue
            action = step.get('uses')
            if action is not None and (not isinstance(action, str) or not re.fullmatch(action_pattern, action)):
                errors.append(f'{name}: action must use a full commit SHA')
            if isinstance(action, str) and action.startswith('actions/checkout@'):
                options = step.get('with', {})
                if not isinstance(options, dict) or options.get('persist-credentials') != 'false':
                    errors.append(f'{name}: checkout must disable persisted credentials')
    return errors


def main():
    files = sorted([*ROOT.glob('s/.github/workflows/*.yml'), *ROOT.glob('faaff/.github/workflows/*.yml')])
    errors = []
    for path in files:
        try:
            errors.extend(f'{path.relative_to(ROOT)}: {e}' for e in validate(path))
        except (OSError, ValueError, yaml.YAMLError) as error:
            errors.append(f'{path.relative_to(ROOT)}: {error}')
    report = {'passed': not errors, 'checks': ['YAML structure', 'unique keys', 'contents read', 'job timeouts', 'full action and reusable-workflow SHA', 'checkout credentials disabled'],
              'workflows': [str(path.relative_to(ROOT)) for path in files], 'errors': errors,
              'scope': 'Local configuration checks; remote Actions execution is not verified'}
    (ROOT / 'catalog/results/settings.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='')
    for error in errors:
        print('ERROR:', error)
    print('WORKFLOW CHECK PASSED' if not errors else 'WORKFLOW CHECK FAILED')
    return bool(errors)


if __name__ == '__main__':
    sys.exit(main())
