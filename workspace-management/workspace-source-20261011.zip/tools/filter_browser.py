import argparse
import html
import json
import os
import subprocess
import tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright
parser=argparse.ArgumentParser(description='Synthetic browser checks using pinned uBO-compiled rules and actual scriptlets')
parser.add_argument('--engine-dir',type=Path,required=True)
parser.add_argument('--report',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
os.environ.setdefault('PLAYWRIGHT_BROWSERS_PATH', str(root/'work/browsers'))
subprocess.run(['node',str(root/'s/scripts/check_engine.mjs'),'--engine-dir',str(args.engine_dir)],check=True)
with tempfile.TemporaryDirectory() as scratch:
 fixture_path=Path(scratch)/'fixtures.json'
 subprocess.run(['node',str(root/'s/scripts/export_browser_fixtures.mjs'),'--engine-dir',str(args.engine_dir),'--output',str(fixture_path)],check=True)
 fixtures=json.loads(fixture_path.read_text(encoding='utf-8'))
checks=[]
APPLY='''({rules,host})=>{const started=performance.now();let changed=0;for(const rule of rules){if(rule.domains.length&&!rule.domains.some(d=>d==='*'||host===d||host.endsWith('.'+d)))continue;const c=rule.compiled;for(const element of document.querySelectorAll(c.selector)){let selected=true;for(const [kind,arg]of c.tasks||[]){if(kind==='matches-css'){const [pattern,flags]=arg.value;selected&&=new RegExp(pattern,flags).test(getComputedStyle(element).getPropertyValue(arg.name))}else if(kind==='has-text'){const m=arg.match(/^\\/(.*)\\/([gimsu]*)$/);selected&&=m?new RegExp(m[1],m[2]).test(element.textContent):element.textContent.includes(arg)}else throw new Error('Unknown procedural task '+kind)}if(!selected)continue;if(c.action){if(c.action[0]!=='style')throw new Error('Unknown action');const style=document.createElement('span').style;style.cssText=c.action[1];for(const property of style)element.style.setProperty(property,style.getPropertyValue(property),style.getPropertyPriority(property))}else element.style.setProperty('display','none','important');changed++}}return{changed,elapsed_ms:performance.now()-started}}'''
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,args=['--no-sandbox']);page=browser.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 script=fixtures['scripts'][0]
 page.set_content('<html><body>Twitch fetch fixture</body></html>')
 page.evaluate("()=>{window.fetchCalls=[];window.fetch=async function(input){fetchCalls.push(typeof input==='string'?input:input.url);return new Response('original')}}")
 page.add_script_tag(content=script['code'])
 result=page.evaluate('''async()=>{const inputs=['https://edge.ads.twitch.tv/test','https://edge.ads.twitch.tv:443/test',new Request('https://edge.ads.twitch.tv/request'),'https://edge.ads.twitch.tv.evil.example/test','https://www.twitch.tv/?url=https://edge.ads.twitch.tv/test','https://usher.ttvnw.net/api/channel/hls/example.m3u8'];const out=[];for(const input of inputs){const response=await fetch(input);out.push(await response.text())}return {out,calls:fetchCalls}}''')
 assert result['out'][:3]==['','',''],result
 assert result['out'][3:]==['original']*3,result
 assert len(result['calls'])==3,result
 checks+=['official no-fetch-if suppresses exact target host','explicit default port and Request inputs supported','lookalike host/query text and player endpoint preserved']
 sponsors=['Sponsored offer','Oferta patrocinada','Offre sponsorisée','Gesponsertes Angebot','Спонсорское предложение','عرض مموّل','スポンサー広告','Sponsorlu içerik','Offerta sponsorizzata']
 legitimate=['Sponsored offers','Watch Sponsored offer','Sponsored offer archive','Watch VOD','Download','Chat']
 markup='<html><body>'+''.join(f'<a id="s{i}">{html.escape(label)}</a>' for i,label in enumerate(sponsors))+''.join(f'<a id="l{i}">{html.escape(label)}</a>' for i,label in enumerate(legitimate))+'</body></html>'
 cosmetic=[r for r in fixtures['cosmetic'] if r['file']=='ad-ubo.txt']
 page.set_content(markup);page.evaluate(APPLY,{'rules':cosmetic,'host':'nosubapp.com'})
 assert page.locator('a:visible').count()==len(legitimate)
 assert all(page.locator(f'#l{i}').is_visible() for i in range(len(legitimate)))
 checks+=['nine exact sponsor translations hidden','near-match and VOD/download/chat links preserved']
 page.set_content(markup);page.evaluate(APPLY,{'rules':cosmetic,'host':'unrelated.example'})
 assert page.locator('a:visible').count()==len(sponsors)+len(legitimate)
 checks.append('cosmetic domain scope respected')
 font_markup='''<html lang="ja"><head><style>body{font-family:Arial}#computed,#deep{font-family:"MS PGothic"}#icon{font-family:"Material Icons"}#computed,#inline,#deep,#icon{line-height:28px;display:block}</style></head><body><p id="computed">日本語本文</p><span id="deep">深い本文</span><p id="inline" style="font-family:MS PGothic">インライン本文</p><i id="icon">icon</i><svg id="svg"></svg></body></html>'''
 standard=[r for r in fixtures['cosmetic'] if r['file']=='japanese-text-softener.txt'];deep=[r for r in fixtures['cosmetic'] if r['file']=='japanese-text-softener-deep.txt']
 page.set_content(font_markup);page.evaluate(APPLY,{'rules':standard,'host':'example.org'})
 values=page.evaluate("Object.fromEntries(['computed','inline','deep','icon'].map(id=>[id,{font:getComputedStyle(document.getElementById(id)).fontFamily,height:getComputedStyle(document.getElementById(id)).lineHeight}]))")
 assert 'system-ui' in values['computed']['font'] and 'system-ui' in values['inline']['font'],values
 assert 'MS PGothic' in values['deep']['font'] and 'Material Icons' in values['icon']['font'],values
 assert all(v['height']=='28px' for v in values.values()),values
 checks+=['compiled font rules change Japanese computed/inline legacy fonts','standard avoids deep span and icon fonts','line-height remains unchanged']
 page.evaluate(APPLY,{'rules':deep,'host':'example.org'});assert 'system-ui' in page.locator('#deep').evaluate('(e)=>getComputedStyle(e).fontFamily')
 checks.append('Deep profile handles Japanese descendant span')
 page.set_content(font_markup.replace('lang="ja"','lang="en"'));page.evaluate(APPLY,{'rules':standard+deep,'host':'example.org'})
 assert 'MS PGothic' in page.locator('#computed').evaluate('(e)=>getComputedStyle(e).fontFamily')
 assert 'MS PGothic' in page.locator('#deep').evaluate('(e)=>getComputedStyle(e).fontFamily')
 checks.append('computed fallback language gate respected')
 page.set_content(font_markup.replace('</body>',''.join('<span style="font-family:MS PGothic">本文</span>' for _ in range(5000))+'</body>'))
 timing=page.evaluate(APPLY,{'rules':standard+deep,'host':'example.org'})
 assert timing['changed']>=5000
 checks.append('large DOM fixture processed without script errors')
 assert not errors,errors
 browser.close()
report={'passed':True,'checks':checks,'scope':'Synthetic DOM and the actual pinned uBO scriptlet functions; not live-site/video E2E','large_dom':timing}
args.report.parent.mkdir(parents=True,exist_ok=True)
args.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n', encoding='utf-8', newline='');print('FILTER BROWSER CHECK PASSED:',len(checks),'checks, DOM',timing)
