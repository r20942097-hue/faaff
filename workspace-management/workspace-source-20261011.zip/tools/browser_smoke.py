"""Optional Chromium checks for the local catalogue (requires Playwright)."""
import json
import os
from pathlib import Path
from urllib.parse import unquote, urlparse

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault('PLAYWRIGHT_BROWSERS_PATH', str(ROOT / 'work/browsers'))
from playwright.sync_api import sync_playwright


def main():
    rows = json.loads((ROOT / 'catalog/generated/inventory.json').read_text(encoding='utf-8'))
    output = ROOT / 'work/browser-check'
    output.mkdir(parents=True, exist_ok=True)
    errors, checks = [], []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1000})
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto((ROOT / 'catalog/generated/inventory.html').as_uri())
        assert page.locator('#rows tr').count() == len(rows)
        checks.append('all inventory rows render')
        for href in page.locator('#rows td.file a').evaluate_all('(links) => links.map(link => link.href)'):
            assert Path(unquote(urlparse(href).path)).is_file(), href
        checks.append('all local artifact links resolve')
        page.select_option('#source', 's')
        assert page.locator('#rows tr').count() == sum(row['source'] == 's' for row in rows)
        checks.append('source filter')
        page.select_option('#category', 'フィルター')
        assert page.locator('#rows tr').count() == sum(row['source'] == 's' and row['category'] == 'フィルター' for row in rows)
        checks.append('combined source/category filter')
        page.fill('#query', 'japanese-text-softener')
        assert page.locator('#rows tr').count() == 2
        checks.append('text search')
        page.fill('#query', 'no-matching-file-123456')
        assert '一致するファイルがありません' in page.locator('#rows').inner_text()
        checks.append('empty-state message')
        page.click('#reset')
        assert page.locator('#rows tr').count() == len(rows)
        checks.append('reset restores full list')
        page.select_option('#state', '候補')
        assert page.locator('#rows tr').count() == 3
        checks.append('candidate filter')
        page.click('#reset')
        page.screenshot(path=str(output / 'desktop.png'), full_page=True)
        page.set_viewport_size({'width': 390, 'height': 844})
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
        page.screenshot(path=str(output / 'mobile.png'), full_page=True)
        checks.append('mobile layout fits viewport')
        page.emulate_media(media='print')
        assert not page.locator('.toolbar').is_visible()
        checks.append('print layout hides controls')
        page.emulate_media(media='screen')
        page.goto((ROOT / 'catalog/generated/filters.html').as_uri())
        profiles = json.loads((ROOT / 's/filter-profiles.json').read_text(encoding='utf-8'))
        assert page.locator('table').first.locator('tbody tr').count() == len(profiles['outputs'])
        checks.append('profile overview matches canonical output count')
        for index, profile in enumerate(profiles['outputs']):
            expected = sum(len(profiles['rule_sets'][key]['rules']) for key in profile['rule_sets'])
            assert page.locator('table').first.locator('tbody tr').nth(index).locator('.number').inner_text() == str(expected)
        checks.append('profile rule counts match canonical data')
        for href in page.locator('a').evaluate_all('(links) => links.map(link => link.href)'):
            assert Path(unquote(urlparse(href).path)).is_file(), href
        checks.append('profile overview links resolve')
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
        page.screenshot(path=str(output / 'profiles-mobile.png'), full_page=True)
        for cell in page.locator('.number').all():
            bounds = cell.bounding_box()
            assert bounds['x'] + bounds['width'] <= 390, bounds
        checks.append('profile overview and rule counts fit mobile viewport')
        page.goto((ROOT / 'catalog/generated/libraries.html').as_uri())
        from manage import dependency_rows
        dependencies = dependency_rows(ROOT)
        assert page.locator('tbody tr').count() == len(dependencies)
        checks.append('library overview matches pinned dependencies')
        for href in page.locator('a').evaluate_all('(links) => links.map(link => link.href)'):
            assert Path(unquote(urlparse(href).path)).is_file(), href
        checks.append('library overview links resolve')
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
        page.screenshot(path=str(output / 'libraries-mobile.png'), full_page=True)
        checks.append('library overview fits mobile viewport')
        page.goto((ROOT / 'catalog/generated/tools.html').as_uri())
        from registry import load
        tools = load()['tools']
        diagnosis = json.loads((ROOT / 'catalog/results/doctor.json').read_text(encoding='utf-8'))
        assert page.locator('tbody tr').count() == len(tools)
        checks.append('tool overview matches shared registry')
        assert '前回の実行結果・日時' in page.locator('thead').inner_text()
        for index, item in enumerate(diagnosis['tools']):
            previous = item.get('last_run', {'label': '未記録', 'time': '—'})
            cell = page.locator('tbody tr').nth(index).locator('td').nth(2).inner_text()
            assert previous['label'] in cell and previous['time'] in cell
        checks.append('tool readiness and previous execution records render separately')
        page.select_option('#state', 'blocked')
        assert page.locator('tbody tr:visible').count() == sum(tool['status'] == 'blocked' for tool in diagnosis['tools'])
        checks.append('tool overview filters missing prerequisites')
        page.select_option('#state', '')
        page.fill('#query', 'Control Plane')
        assert page.locator('tbody tr:visible').count() == 2
        checks.append('tool overview searches recovered control-plane tools')
        page.fill('#query', 'no-matching-tool-123456')
        assert page.locator('#empty').is_visible()
        checks.append('tool overview empty-state message')
        page.fill('#query', '')
        for href in page.locator('a').evaluate_all('(links) => links.map(link => link.href)'):
            assert Path(unquote(urlparse(href).path)).is_file(), href
        checks.append('tool overview links resolve')
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
        page.screenshot(path=str(output / 'tools-mobile.png'), full_page=True)
        checks.append('tool overview fits mobile viewport')
        page.goto((ROOT / 'catalog/generated/projects.html').as_uri())
        from projects import load as load_projects
        products = load_projects(ROOT / 'catalog/projects.json')['products']
        assert page.locator('tbody tr').count() == len(products)
        checks.append('product overview matches current inventory')
        page.select_option('#source', 'missing')
        assert page.locator('tbody tr:visible').count() == sum(product['source_state'] == 'missing' for product in products)
        checks.append('product overview filters missing source')
        page.fill('#query', 'AI Orchestrator')
        assert page.locator('tbody tr:visible').count() == 1
        checks.append('product overview combines source and text filters')
        page.fill('#query', 'no-matching-product-123456')
        assert page.locator('#empty').is_visible()
        checks.append('product overview empty-state message')
        page.click('#reset')
        assert page.locator('tbody tr:visible').count() == len(products)
        checks.append('product overview resets filters')
        for href in page.locator('a').evaluate_all('(links) => links.map(link => link.href)'):
            assert Path(unquote(urlparse(href).path)).is_file(), href
        checks.append('product overview links resolve')
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
        page.screenshot(path=str(output / 'projects-mobile.png'), full_page=True)
        checks.append('product overview fits mobile viewport')
        assert not errors, errors
        checks.append('no JavaScript page errors')
        browser.close()
    result = {'passed': True, 'checks': checks, 'inventory_count': len(rows),
              'scope': 'Catalogue and profile-selection UI only; not uBlock filter-engine or recording E2E'}
    (ROOT / 'catalog/results/browser.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='')
    print(f'BROWSER CHECK PASSED: {len(checks)} checks')


if __name__ == '__main__':
    main()
