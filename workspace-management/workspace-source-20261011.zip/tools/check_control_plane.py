"""Verify pinned runtime and test it in a disposable local directory."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from registry import child_environment

ROOT = Path(__file__).resolve().parents[1]


def main():
    scratch = ROOT / 'work/control-plane-check'
    scratch.mkdir(parents=True, exist_ok=True)
    results = []
    with TemporaryDirectory(dir=scratch) as directory:
        runtime = Path(directory) / 'runtime'
        commands = [
            [sys.executable, str(ROOT / 'library-files/tool-sources/portfolio/control-plane-v9/extract_source.py'), '--out', str(runtime)],
            [sys.executable, str(runtime / 'tools/test_promotion_safety.py')],
            [sys.executable, str(runtime / 'tools/ci_selftest.py')],
            [sys.executable, str(runtime / 'tools/static_safety_check.py'), str(runtime)],
        ]
        for command in commands:
            completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, encoding='utf-8', env=child_environment(), timeout=120, check=False)
            output = completed.stdout + completed.stderr
            results.append({'step': Path(command[1]).name, 'exit_code': completed.returncode, 'output': output})
            print(output, end='')
            if completed.returncode:
                break
    report = {'schema': 'control-plane-local-check/v1', 'passed': len(results) == 4 and all(r['exit_code'] == 0 for r in results),
              'scope': 'Pinned source extraction and synthetic local database tests. No real product promotion or remote publication.', 'checks': results}
    path = ROOT / 'catalog/results/control-plane.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='')
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
