"""Run the pinned Next verifier with a compression-portable rebuild comparison.

The original verifier is retained byte-for-byte. Only its rebuild comparison is
adapted: immutable ZIP identity and payload checks still run before extraction,
metadata and payload must match, and two builds on this runtime must be identical.
"""
import hashlib
import io
from pathlib import Path
import subprocess
import sys
import zipfile
from registry import child_environment

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'library-files/tool-sources/security/control_plane_next'


def archive_identity(body):
    with zipfile.ZipFile(io.BytesIO(body)) as archive:
        return [(item.filename, item.date_time, item.create_system, item.external_attr,
                 item.compress_type, item.flag_bits, item.extra, item.comment,
                 archive.read(item)) for item in archive.infolist()]


def rebuilt_matches(rebuilt, original):
    candidate = rebuilt.read_bytes()
    if archive_identity(candidate) != archive_identity(original):
        return False
    # Compression libraries can differ across OS/Python builds. Reproducibility
    # must still hold when rebuilding twice in the same environment.
    second = rebuilt.with_name('second-rebuild.zip')
    subprocess.run([sys.executable, str(SOURCE / 'build_source_archive.py'),
                    '--source-dir', str(rebuilt.parent / 'source'), '--archive', str(second),
                    '--checksum', str(second.with_suffix('.sha256'))], check=True,
                   env=child_environment(), stdout=subprocess.DEVNULL)
    return candidate == second.read_bytes()


def main():
    manifest = __import__('json').loads((ROOT / 'library-files/tool-sources/security/SOURCE-ORIGIN.json').read_text(encoding='utf-8'))
    verifier = SOURCE / 'verify_source_archive.py'
    for name in ['verify_source_archive.py', 'build_source_archive.py']:
        expected = next(item['sha256'] for item in manifest['files'] if item['path'] == 'control_plane_next/' + name)
        if hashlib.sha256((SOURCE / name).read_bytes()).hexdigest() != expected:
            raise ValueError('pinned source identity changed: ' + name)
    code = verifier.read_text(encoding='utf-8')
    old = 'if rebuilt.read_bytes() != archive_bytes:'
    if code.count(old) != 1:
        raise ValueError('pinned verifier comparison changed; review adapter')
    namespace = {'__file__': str(verifier), '__name__': 'pinned_next_verifier', 'rebuilt_matches': rebuilt_matches}
    exec(compile(code.replace(old, 'if not rebuilt_matches(rebuilt, archive_bytes):'), str(verifier), 'exec'), namespace)
    return namespace['main']()


if __name__ == '__main__':
    raise SystemExit(main())
