"""Install the hashed verification environment, including Python 3.15's YAML build."""
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone
from registry import child_environment, write_report
from check_python_lock import verify_files

ROOT = Path(__file__).resolve().parents[1]


def main():
    destination = ROOT / 'catalog/results/python-setup.json'
    report = {'schema': 'verification-environment-setup/v1', 'python': sys.version.split()[0],
              'started_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'running', 'passed': False,
              'pyyaml_profile': 'hashed-source/pure-python' if sys.version_info >= (3, 15) else 'hashed-binary', 'checks': []}
    write_report(destination, report)
    if sys.prefix == sys.base_prefix:
        report.update(status='blocked', finished_at_utc=datetime.now(timezone.utc).isoformat())
        write_report(destination, report)
        print('BLOCKED: Run this installer with a virtual-environment Python.')
        return 2
    try:
        verify_files(ROOT)
    except (OSError, ValueError) as error:
        report.update(status='failed', error=str(error), finished_at_utc=datetime.now(timezone.utc).isoformat())
        write_report(destination, report)
        print('FAILED: ' + str(error))
        return 1
    cache = ROOT / 'work/python-package-cache'
    environment = child_environment()
    environment['PIP_DISABLE_PIP_VERSION_CHECK'] = '1'
    commands = []
    base = [sys.executable, '-m', 'pip', 'install', '--cache-dir', str(cache), '--require-hashes', '--only-binary=:all:']
    if sys.version_info >= (3, 15):
        commands.append([*base, '-r', 'tools/requirements-build.lock.txt'])
        environment['PYYAML_FORCE_LIBYAML'] = '0'
        environment['PYYAML_FORCE_CYTHON'] = '0'
        commands.append([*base, '--no-build-isolation', '--no-binary=PyYAML', '-r', 'tools/requirements-verification.lock.txt'])
    else:
        commands.append([*base, '-r', 'tools/requirements-verification.lock.txt'])
    if sys.version_info >= (3, 15):
        commands.append([sys.executable, '-c',
                         'import yaml; assert not yaml.__with_libyaml__, "Use a fresh virtual environment for the pure-Python YAML profile"; '
                         'assert yaml.safe_load("ready: true") == {"ready": True}; print("Pure-Python PyYAML import and parse passed")'])
    commands.extend([[sys.executable, '-m', 'pip', 'check'],
                     [sys.executable, 'tools/check_python_lock.py', '--installed']])
    for command in commands:
        try:
            completed = subprocess.run(command, cwd=ROOT, env=environment, timeout=300, shell=False,
                                       capture_output=True, text=True, encoding='utf-8', errors='backslashreplace')
        except (OSError, subprocess.TimeoutExpired, KeyboardInterrupt) as error:
            code = 130 if isinstance(error, KeyboardInterrupt) else 124 if isinstance(error, subprocess.TimeoutExpired) else 127
            report.update(status='interrupted' if code == 130 else 'failed', error=type(error).__name__,
                          finished_at_utc=datetime.now(timezone.utc).isoformat())
            write_report(destination, report)
            print('FAILED: ' + type(error).__name__)
            return code
        output = completed.stdout + completed.stderr
        print(output, end='' if output.endswith('\n') else '\n', flush=True)
        report['checks'].append({'argv': command[1:], 'exit_code': completed.returncode, 'output': output})
        write_report(destination, report)
        if completed.returncode:
            report.update(status='failed', finished_at_utc=datetime.now(timezone.utc).isoformat())
            write_report(destination, report)
            return completed.returncode
    report.update(status='passed', passed=True, finished_at_utc=datetime.now(timezone.utc).isoformat())
    write_report(destination, report)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
