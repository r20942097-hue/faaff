import glob,json,traceback,threading,html,time
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.common.proxy import Proxy,ProxyType
from selenium.webdriver.support.ui import WebDriverWait
import argparse
parser=argparse.ArgumentParser(description='Actual signed Firefox extension checks on controlled local fixtures')
parser.add_argument('--root',type=Path,required=True,help='directory containing geckodriver and filters.json')
parser.add_argument('--addon',type=Path,required=True)
args=parser.parse_args()
root=args.root;filters=json.loads((root/'filters.json').read_text(encoding='utf-8'));checks=[];requests=[];driver=None
sponsors=['Sponsored offer','Oferta patrocinada','Offre sponsorisée','Gesponsertes Angebot','Спонсорское предложение','عرض مموّل','スポンサー広告','Sponsorlu içerik','Offerta sponsorizzata']
normal=['Sponsored offers','Sponsored offer now','Download VOD','Chat','VOD player']
font_markup='<html lang="ja"><head><style>body{font-family:Arial}#computed,#deep{font-family:"MS PGothic"}#icon{font-family:"Material Icons"}#computed,#inline,#deep,#icon{line-height:28px;display:block}</style></head><body><p id="computed">日本語本文</p><span id="deep">深い本文</span><p id="inline" style="font-family:MS PGothic">インライン本文</p><i id="icon">icon</i><svg id="svg"></svg></body></html>'
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_CONNECT(self):
  requests.append({'method':'CONNECT','target':self.path});self.send_error(502,'Synthetic fixture does not establish external connections')
 def do_GET(self):
  parsed=urlparse(self.path);host=parsed.hostname or self.headers.get('Host','').split(':')[0];path=parsed.path
  requests.append({'method':'GET','host':host,'path':path})
  if path.startswith('/test-resource'):body=b'fixture-response';kind='text/plain'
  elif host=='nosubapp.com':body=('<html><body>'+''.join(f'<a id="s{i}">{html.escape(label)}</a>' for i,label in enumerate(sponsors))+''.join(f'<a id="l{i}">{html.escape(label)}</a>' for i,label in enumerate(normal))+'</body></html>').encode();kind='text/html'
  elif host=='font.example':body=font_markup.encode();kind='text/html'
  else:body=b'<html><body><p id="content">Controlled fixture</p><div class="disclosure-card">Ad</div><div class="prime-offer">Ad</div><div class="prime-offers-upsell">Ad</div><div id="directory-banner">Ad</div><div id="directory-rectangle">Ad</div></body></html>';kind='text/html'
  self.send_response(200);self.send_header('Content-Type',kind+'; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.send_header('Access-Control-Allow-Origin','*');self.end_headers();self.wfile.write(body)
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
report={'passed':False,'scope':'Signed Firefox uBO on controlled local HTTP proxy fixtures. No external requests, authentication or live-video E2E. Default lists disabled to attribute behavior to supplied rules.','checks':checks}
def send(message):
 return driver.execute_async_script("const done=arguments[arguments.length-1];const api=window.wrappedJSObject?.vAPI||window.vAPI;api.messaging.send('dashboard',arguments[0]).then(v=>done(v??null),e=>done({error:String(e)}));",message)
def configure(names):
 driver.get('moz-extension://'+uuid+'/1p-filters.html');WebDriverWait(driver,15).until(lambda d:d.execute_script('return typeof (window.wrappedJSObject?.vAPI||window.vAPI)==="object"'))
 content='\n'.join(line for name in names for line in filters[name].splitlines() if line and not line.startswith(('!','[')))
 result=send({'what':'writeUserFilters','content':content,'enabled':True,'trusted':False})
 if isinstance(result,dict) and result.get('error'):raise ValueError(result)
 send({'what':'applyFilterListSelection','toSelect':['user-filters'],'merge':False})
 send({'what':'reloadAllFilters'})
 result=send({'what':'readUserFilters'});assert result['content'].strip()==content.strip(),result
 return content
def fetch(url):
 return driver.execute_async_script("const done=arguments[arguments.length-1];fetch(arguments[0]).then(async r=>done({status:r.status,body:await r.text()})).catch(e=>done({error:String(e)}));",url)
try:
 options=Options();options.add_argument('-headless');options.binary_location=glob.glob('/ms-playwright/firefox-*/firefox/firefox')[0]
 proxy=Proxy();proxy.proxy_type=ProxyType.MANUAL;proxy.http_proxy='127.0.0.1:'+str(server.server_port);proxy.ssl_proxy=proxy.http_proxy;options.proxy=proxy
 options.ignore_local_proxy_environment_variables();options.set_preference('network.dns.disablePrefetch',True)
 service=Service(executable_path=str(root/'geckodriver'),log_output=str(root/'geckodriver-fixtures.log'),service_args=['--allow-system-access'])
 driver=webdriver.Firefox(options=options,service=service);driver.set_page_load_timeout(20);driver.set_script_timeout(30)
 addon=driver.install_addon(str(args.addon),temporary=False);assert addon=='uBlock0@raymondhill.net'
 driver.set_context('chrome');mapping=json.loads(driver.execute_script("return Services.prefs.getStringPref('extensions.webextensions.uuids');"));uuid=mapping[addon];driver.set_context('content')
 report['browser_version']=driver.capabilities['browserVersion'];report['extension_version']='1.75.0'
 driver.get('moz-extension://'+uuid+'/dashboard.html');assert 'Dashboard' in driver.title;checks.append('signed extension dashboard opens')
 configure(['ad.txt','tracking.txt']);checks.append('actual filter storage and reload')
 driver.get('http://publisher.example/test-page')
 before=len(requests);blocked=fetch('http://doubleclick.net/test-resource-blocked');assert 'error' in blocked,blocked
 assert not any(r.get('host')=='doubleclick.net' for r in requests[before:]),requests[before:];checks.append('third-party ad request blocked by extension')
 assert fetch('http://doubleclick.net.evil.example/test-resource-lookalike')['body']=='fixture-response';checks.append('lookalike host request preserved')
 driver.get('http://doubleclick.net/test-page');assert fetch('http://doubleclick.net/test-resource-firstparty')['body']=='fixture-response';checks.append('first-party request preserved')
 configure(['ad-ubo.txt']);driver.get('http://nosubapp.com/test-page')
 WebDriverWait(driver,15).until(lambda d:not d.find_element('id','s0').is_displayed())
 assert all(not driver.find_element('id',f's{i}').is_displayed() for i in range(len(sponsors)));checks.append('nine translated sponsor labels hidden by extension')
 assert all(driver.find_element('id',f'l{i}').is_displayed() for i in range(len(normal)));checks.append('near-match and VOD/chat links preserved')
 driver.get('http://www.twitch.tv/test-page');WebDriverWait(driver,15).until(lambda d:not d.find_element('class name','disclosure-card').is_displayed())
 assert all(not driver.find_element('class name',name).is_displayed() for name in ['disclosure-card','prime-offer','prime-offers-upsell'])
 assert all(not driver.find_element('id',name).is_displayed() for name in ['directory-banner','directory-rectangle']);checks.append('Twitch ad UI hidden by extension')
 before=len(requests);response=fetch('https://edge.ads.twitch.tv/test-scriptlet');assert response.get('status')==200 and response.get('body')=='',response
 assert not any(r.get('target','').startswith('edge.ads.twitch.tv:') for r in requests[before:]);checks.append('actual no-fetch-if prevents exact-host fetch')
 before=len(requests);fetch('https://usher.ttvnw.net/test-player');assert any(r.get('target','').startswith('usher.ttvnw.net:') for r in requests[before:]),requests[before:];checks.append('player fetch initiation preserved')
 configure(['japanese-text-softener.txt']);driver.get('http://font.example/test-page')
 WebDriverWait(driver,15).until(lambda d:'system-ui' in d.execute_script('return getComputedStyle(document.querySelector("#computed")).fontFamily'))
 fonts=driver.execute_script('return Object.fromEntries(["computed","inline","deep","icon"].map(id=>[id,{font:getComputedStyle(document.getElementById(id)).fontFamily,height:getComputedStyle(document.getElementById(id)).lineHeight}]))')
 assert 'system-ui' in fonts['computed']['font'] and 'system-ui' in fonts['inline']['font'],fonts
 assert 'MS PGothic' in fonts['deep']['font'] and 'Material Icons' in fonts['icon']['font'],fonts
 assert all(v['height']=='28px' for v in fonts.values()),fonts;checks.append('Japanese standard font scope, icons and line height preserved')
 configure(['japanese-text-softener.txt','japanese-text-softener-deep.txt']);driver.get('http://font.example/test-page')
 WebDriverWait(driver,15).until(lambda d:'system-ui' in d.execute_script('return getComputedStyle(document.querySelector("#deep")).fontFamily'));checks.append('Japanese Deep changes descendant font through extension')
 driver.save_screenshot(str(root/'font-fixture.png'));report['passed']=True
except Exception as error:
 report['error']=str(error)
 if driver:
  try:report['failure_fonts']=driver.execute_script('return Object.fromEntries(["computed","inline","deep","icon"].map(id=>[id,{font:getComputedStyle(document.getElementById(id)).fontFamily,height:getComputedStyle(document.getElementById(id)).lineHeight}]))')
  except Exception:pass
 traceback.print_exc()
finally:
 if driver:
  try:driver.quit()
  except Exception:pass
 server.shutdown();(root/'fixtures-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2), encoding='utf-8', newline='');print(json.dumps(report,ensure_ascii=False));raise SystemExit(0 if report['passed'] else 1)
