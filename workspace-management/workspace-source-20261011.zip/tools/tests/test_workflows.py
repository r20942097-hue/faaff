from importlib.util import find_spec
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
if find_spec('yaml'):
    from check_workflows import validate


@unittest.skipUnless(find_spec('yaml'), 'Optional workflow checks require PyYAML')
class WorkflowTests(unittest.TestCase):
    def check(self, text):
        with TemporaryDirectory() as directory:
            path = Path(directory) / 'workflow.yml'
            path.write_text(text, encoding='utf-8')
            return validate(path)

    def test_malformed_jobs_and_permissions_return_errors_without_crashing(self):
        for text in ['jobs: bad', 'permissions: read\njobs:\n  build: broken',
                     'permissions: [read]\njobs:\n  build: broken']:
            with self.subTest(text=text):
                self.assertTrue(self.check(text))

    def test_malformed_steps_and_action_values_return_errors_without_crashing(self):
        prefix = 'permissions:\n  contents: read\njobs:\n  build:\n    timeout-minutes: 10\n'
        for steps in ['    steps: bad', '    steps: [bad]', '    steps:\n      - uses: [bad]',
                      '    steps:\n      - uses: actions/checkout@' + 'a'*40 + '\n        with: bad',
                      '    timeout-minutes: [10]']:
            with self.subTest(steps=steps):
                if 'timeout-minutes:' in steps:
                    self.assertTrue(self.check(prefix.replace('    timeout-minutes: 10\n', '') + steps))
                else:
                    self.assertTrue(self.check(prefix + steps))

    def test_duplicate_and_structured_keys_are_rejected(self):
        for text in ['jobs: {}\njobs: {}', '? [a, b]\n: value']:
            with self.subTest(text=text), self.assertRaises(ValueError):
                self.check(text)

    def test_pinned_checkout_is_valid_and_unpinned_action_is_rejected(self):
        text = ('permissions:\n  contents: read\njobs:\n  build:\n    timeout-minutes: 10\n'
                '    steps:\n      - uses: actions/checkout@' + 'a'*40 + '\n'
                '        with:\n          persist-credentials: false\n')
        self.assertEqual(self.check(text), [])
        self.assertTrue(self.check(text.replace('a'*40, 'main')))
