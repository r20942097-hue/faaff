from pathlib import Path
import json
import sys
from tempfile import TemporaryDirectory
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from doctor import inspect, last_run
from registry import load


class ReadinessTests(unittest.TestCase):
    def test_previous_failure_is_separate_from_readiness_and_time_is_jst(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'catalog/results/tool-catalogue.json'
            path.parent.mkdir(parents=True)
            path.write_text(json.dumps({'schema': 'workspace-tool-run/v1', 'tool': 'catalogue',
                                       'status': 'failed', 'passed': False, 'started_at_utc': '2026-10-11T12:00:00+00:00'}))
            previous = last_run(root, 'catalogue')
            self.assertEqual(previous, {'label': '失敗', 'time': '2026-10-11 21:00:00 JST'})

    def test_invalid_and_legacy_records_cannot_claim_current_success(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / 'catalog/results/tool-catalogue.json'
            path.parent.mkdir(parents=True)
            path.write_text('{"passed":true}')
            self.assertEqual(last_run(root, 'catalogue')['label'], '旧形式の記録')
            path.write_text(json.dumps({'schema': 'workspace-tool-run/v1', 'tool': 'catalogue',
                                       'status': 'failed', 'passed': True, 'started_at_utc': '2026-10-11T12:00:00+00:00'}))
            self.assertEqual(last_run(root, 'catalogue')['label'], '記録を確認してください')

    def test_missing_recording_source_stays_blocked(self):
        with TemporaryDirectory() as directory:
            report = inspect(directory, executable=lambda name: '/bin/' + name, module=lambda name: object())
            recording = next(row for row in report['tools'] if row['id'] == 'recording')
            self.assertEqual(recording['status'], 'blocked')
            self.assertIn('file: faaff/rplay_watcher/__init__.py', recording['missing'])

    def test_source_escape_not_accepted(self):
        with TemporaryDirectory() as directory, TemporaryDirectory() as outside:
            root = Path(directory)
            (Path(outside) / 'manage.py').write_text('')
            (root / 'tools').symlink_to(outside, target_is_directory=True)
            report = inspect(root, executable=lambda name: None, module=lambda name: None)
            self.assertIn('file: tools/manage.py', report['tools'][0]['missing'])
            engine = next(row for row in report['tools'] if row['id'] == 'engine')
            self.assertIn('command: node', engine['missing'])

    def test_ready_requires_all_dependencies(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            for tool in load()['tools']:
                for name in tool['files']:
                    path = root / name
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.touch()
            report = inspect(root, executable=lambda name: '/bin/' + name, module=lambda name: object())
            self.assertTrue(all(row['status'] == 'ready' for row in report['tools'] if row['id'] != 'recording'))
            self.assertEqual(next(row for row in report['tools'] if row['id'] == 'recording')['status'], 'blocked')
