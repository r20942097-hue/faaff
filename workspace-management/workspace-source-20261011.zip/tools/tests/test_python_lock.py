import copy
from importlib.metadata import PackageNotFoundError
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from check_python_lock import validate, installed


class LockTests(unittest.TestCase):
    def setUp(self):
        self.data = {'schema': 'python-verification-lock/v1', 'python': '>=3.11', 'packages': [
            {'name': 'example', 'version': '1.2.3', 'marker': '', 'role': 'direct', 'files': [
                {'filename': 'example.whl', 'sha256': 'a'*64, 'url': 'https://files.pythonhosted.org/example.whl'}]}]}

    def test_alias_duplicate_rejected(self):
        self.data['packages'][0]['name'] = 'typing_extensions'
        duplicate = copy.deepcopy(self.data['packages'][0])
        duplicate['name'] = 'typing-extensions'
        self.data['packages'].append(duplicate)
        with self.assertRaises(ValueError):
            validate(self.data)

    def test_missing_or_wrong_version_is_not_pass(self):
        self.assertEqual(installed(self.data, lookup=lambda name: '1.2.4')[0]['status'], 'mismatch')
        def missing(name):
            raise PackageNotFoundError(name)
        self.assertEqual(installed(self.data, lookup=missing)[0]['status'], 'mismatch')

    def test_windows_dependency_not_claimed_on_linux(self):
        self.data['packages'][0]['marker'] = 'sys_platform == "win32"'
        self.assertEqual(installed(self.data, lookup=lambda name: '1.2.3', platform='linux')[0]['status'], 'not-applicable')
        self.assertEqual(installed(self.data, lookup=lambda name: '1.2.3', platform='win32')[0]['status'], 'match')

    def test_bad_identity_and_marker_rejected(self):
        invalid = copy.deepcopy(self.data)
        invalid['packages'][0]['files'][0]['sha256'] = '0'
        with self.assertRaises(ValueError):
            validate(invalid)
        self.data['packages'][0]['marker'] = '__import__("os")'
        with self.assertRaises(ValueError):
            validate(self.data)

    def test_wrong_json_types_rejected_cleanly(self):
        for key in ['name', 'version', 'marker', 'role']:
            with self.subTest(key=key):
                invalid = copy.deepcopy(self.data)
                invalid['packages'][0][key] = []
                with self.assertRaises(ValueError):
                    validate(invalid)
        for key in ['sha256', 'url', 'filename']:
            with self.subTest(key=key):
                invalid = copy.deepcopy(self.data)
                invalid['packages'][0]['files'][0][key] = []
                with self.assertRaises(ValueError):
                    validate(invalid)
        self.data['packages'] = [None]
        with self.assertRaises(ValueError):
            validate(self.data)
