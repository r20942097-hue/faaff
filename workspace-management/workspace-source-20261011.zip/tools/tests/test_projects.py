import copy
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from projects import load, validate, views


class ProjectInventoryTests(unittest.TestCase):
    def setUp(self):
        self.data = load(Path(__file__).resolve().parents[2] / 'catalog/projects.json')

    def test_unavailable_source_cannot_claim_verified_e2e(self):
        self.data['products'][0]['current_product_e2e'] = '合格'
        with self.assertRaisesRegex(ValueError, 'cannot claim'):
            validate(self.data)

    def test_duplicate_invalid_dates_and_field_types_rejected(self):
        variants = [copy.deepcopy(self.data) for _ in range(4)]
        variants[0]['products'].append(variants[0]['products'][0])
        variants[1]['products'][0]['historical_record_date'] = '2026-13-01'
        variants[2]['products'][0]['next'] = []
        variants[3]['products'][0]['source_state'] = 'maybe'
        for data in variants:
            with self.assertRaises(ValueError):
                validate(data)

    def test_untrusted_product_text_is_escaped(self):
        self.data['products'][0]['name'] = '<script>alert(1)</script>'
        page = views(self.data)['projects.html']
        self.assertNotIn('<script>alert(1)</script>', page)
        self.assertIn('&lt;script&gt;alert(1)&lt;/script&gt;', page)
