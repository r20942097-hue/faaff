import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from check_sources import inspect


class SourceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / 'tool.py').write_text('print("original")\n')
        self.origin = {'repository': 'owner/repo', 'commit': 'a'*40, 'archive_sha256': 'b'*64,
                       'files': [{'path': 'tool.py', 'sha256': hashlib.sha256((self.root / 'tool.py').read_bytes()).hexdigest()}]}
        self.save()

    def save(self):
        (self.root / 'SOURCE-ORIGIN.json').write_text(json.dumps(self.origin))

    def test_changes_and_missing_sources_cannot_pass(self):
        self.assertTrue(inspect(self.root)['passed'])
        (self.root / 'tool.py').write_text('print("changed")\n')
        self.assertFalse(inspect(self.root)['passed'])
        (self.root / 'tool.py').unlink()
        self.assertIsNone(inspect(self.root)['mismatches'][0]['actual'])

    def test_extra_code_rejected_but_runtime_cache_ignored(self):
        cache = self.root / '__pycache__'
        cache.mkdir()
        (cache / 'tool.pyc').write_bytes(b'cache')
        self.assertTrue(inspect(self.root)['passed'])
        (self.root / 'unexpected.py').write_text('new code')
        self.assertEqual(inspect(self.root)['unrecorded_files'], ['unexpected.py'])

    def test_path_escape_duplicate_and_symlink_rejected(self):
        self.origin['files'][0]['path'] = '../outside'
        self.save()
        with self.assertRaises(ValueError):
            inspect(self.root)
        self.origin['files'][0]['path'] = 'tool.py'
        self.origin['files'].append(self.origin['files'][0].copy())
        self.save()
        with self.assertRaises(ValueError):
            inspect(self.root)
        self.origin['files'].pop()
        self.save()
        (self.root / 'tool.py').unlink()
        (self.root / 'tool.py').symlink_to(self.root / 'missing')
        with self.assertRaises(ValueError):
            inspect(self.root)
