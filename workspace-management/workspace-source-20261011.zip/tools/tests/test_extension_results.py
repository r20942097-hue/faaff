import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from check_extension import record_result


class ExtensionResultTests(unittest.TestCase):
    def test_failed_or_missing_report_never_reuses_success(self):
        with tempfile.TemporaryDirectory() as directory:
            source, target = Path(directory) / 'source.json', Path(directory) / 'latest.json'
            lock = {'image': 'pinned-image', 'addon': {}, 'driver': {}}
            source.write_text(json.dumps({'passed': True, 'checks': ['fixture']}))
            self.assertTrue(record_result(lock, source, target, 0))
            self.assertFalse(record_result(lock, source, target, 1))
            self.assertFalse(json.loads(target.read_text())['passed'])
            self.assertFalse(record_result(lock, source, target, 124, 'timeout'))
            source.unlink()
            self.assertFalse(record_result(lock, source, target, 0))
            self.assertIn('not produced', json.loads(target.read_text())['error'])

    def test_empty_or_false_fixture_report_cannot_pass(self):
        with tempfile.TemporaryDirectory() as directory:
            source, target = Path(directory) / 'source.json', Path(directory) / 'latest.json'
            lock = {'image': 'pinned-image', 'addon': {}, 'driver': {}}
            for report in [{'passed': True, 'checks': []}, {'passed': False, 'checks': ['fixture']}]:
                source.write_text(json.dumps(report))
                self.assertFalse(record_result(lock, source, target, 0))
