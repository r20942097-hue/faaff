import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from extract_snapshot import checked_archive, extract


def snapshot(files, manifest=None):
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w') as archive:
        for name, body in files.items():
            archive.writestr(name, body)
        identities = manifest if manifest is not None else {name: hashlib.sha256(body).hexdigest() for name, body in files.items()}
        archive.writestr('CONTENT_MANIFEST_SHA256.json', json.dumps(identities))
    body = output.getvalue()
    return body, hashlib.sha256(body).hexdigest()


class SnapshotTests(unittest.TestCase):
    def test_raw_archive_name_cannot_hide_unsafe_suffix(self):
        output = io.BytesIO()
        with zipfile.ZipFile(output, 'w') as archive:
            member = zipfile.ZipInfo('safe.txt')
            member.filename = 'safe.txt\x00hidden'
            member.orig_filename = member.filename
            archive.writestr(member, b'data')
            archive.writestr('CONTENT_MANIFEST_SHA256.json', json.dumps({'safe.txt': hashlib.sha256(b'data').hexdigest()}))
        body = output.getvalue()
        with self.assertRaisesRegex(ValueError, 'normalized'):
            checked_archive(body, hashlib.sha256(body).hexdigest())

    def test_payload_modified_even_with_correct_outer_hash(self):
        body, digest = snapshot({'a.txt': b'changed'}, {'a.txt': hashlib.sha256(b'original').hexdigest()})
        with self.assertRaisesRegex(ValueError, 'payload'):
            checked_archive(body, digest)

    def test_outer_identity_must_match(self):
        body, _ = snapshot({'a.txt': b'original'})
        with self.assertRaisesRegex(ValueError, 'expected SHA256'):
            checked_archive(body, '0'*64)

    def test_nonportable_and_escape_paths_rejected(self):
        for path in ['../outside', '/absolute', 'C:/file', 'a\\file', 'CON.txt', 'a./file', '.aws/key', 'a//b']:
            with self.subTest(path=path):
                body, digest = snapshot({path: b'data'})
                with self.assertRaises(ValueError):
                    checked_archive(body, digest)

    def test_case_unicode_and_parent_collisions_rejected(self):
        for files in [{'A.txt': b'a', 'a.txt': b'b'}, {'é.txt': b'a', 'e\u0301.txt': b'b'}, {'a': b'a', 'a/b': b'b'}, {'A': b'a', 'a/b': b'b'}]:
            body, digest = snapshot(files)
            with self.assertRaises(ValueError):
                checked_archive(body, digest)

    def test_inventory_missing_and_extra_cannot_pass(self):
        for manifest in [{}, {'a.txt': 'a'*64, 'missing.txt': 'b'*64}]:
            body, digest = snapshot({'a.txt': b'data'}, manifest)
            with self.assertRaisesRegex(ValueError, 'inventory'):
                checked_archive(body, digest)

    def test_new_output_only_and_no_writes_before_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            body, digest = snapshot({'a/file.txt': b'data'})
            archive, target = root / 'source.zip', root / 'out'
            archive.write_bytes(body)
            with self.assertRaises(ValueError):
                extract(archive, '0'*64, target)
            self.assertFalse(target.exists())
            self.assertEqual(extract(archive, digest, target), 2)
            with self.assertRaises(ValueError):
                extract(archive, digest, target)
            self.assertEqual((target / 'a/file.txt').read_bytes(), b'data')
