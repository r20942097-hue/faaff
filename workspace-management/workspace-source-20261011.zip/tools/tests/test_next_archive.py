import io
from pathlib import Path
import sys
import unittest
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from check_next_archive import archive_identity


def archive(body, level=9, mode=0o100644):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w') as result:
        info = zipfile.ZipInfo('source.txt', (2026, 10, 1, 0, 0, 0))
        info.create_system = 3
        info.external_attr = mode << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        result.writestr(info, body, compresslevel=level)
    return stream.getvalue()


class RebuildIdentityTests(unittest.TestCase):
    def test_compression_difference_preserves_identity(self):
        body = b'portable-source-content ' * 1000
        first, second = archive(body, 1), archive(body, 9)
        self.assertNotEqual(first, second)
        self.assertEqual(archive_identity(first), archive_identity(second))

    def test_payload_and_permissions_must_match(self):
        original = archive(b'original')
        for changed in [archive(b'changed'), archive(b'original', mode=0o100755)]:
            self.assertNotEqual(archive_identity(original), archive_identity(changed))
