import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import setup_verification


class SetupTests(unittest.TestCase):
    def test_global_interpreter_is_blocked_without_installation(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            destination = root / 'catalog/results/python-setup.json'
            destination.parent.mkdir(parents=True)
            destination.write_text('{"passed":true}')
            with patch.object(setup_verification, 'ROOT', root), patch.object(sys, 'prefix', 'base'), patch.object(sys, 'base_prefix', 'base'), patch('setup_verification.subprocess.run') as runner:
                self.assertEqual(setup_verification.main(), 2)
                runner.assert_not_called()
            report = json.loads(destination.read_text(encoding='utf-8'))
            self.assertFalse(report['passed'])
            self.assertEqual(report['status'], 'blocked')

    def test_invalid_lock_prevents_installation_and_invalidates_old_success(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            destination = root / 'catalog/results/python-setup.json'
            destination.parent.mkdir(parents=True)
            destination.write_text('{"passed":true}')
            with patch.object(setup_verification, 'ROOT', root), patch.object(sys, 'prefix', 'virtual'), patch.object(sys, 'base_prefix', 'base'), patch('setup_verification.subprocess.run') as runner:
                self.assertEqual(setup_verification.main(), 1)
                runner.assert_not_called()
            report = json.loads(destination.read_text(encoding='utf-8'))
            self.assertFalse(report['passed'])
            self.assertEqual(report['status'], 'failed')

    def test_common_setup_entry_blocks_global_installation(self):
        import manage
        with TemporaryDirectory() as directory:
            root = Path(directory)
            with patch.object(setup_verification, 'ROOT', root), patch.object(sys, 'prefix', 'base'), patch.object(sys, 'base_prefix', 'base'), patch.object(sys, 'argv', ['manage.py', 'setup']), patch('setup_verification.subprocess.run') as runner:
                self.assertEqual(manage.main(), 2)
                runner.assert_not_called()
            report = json.loads((root / 'catalog/results/python-setup.json').read_text())
            self.assertFalse(report['passed'])
            self.assertEqual(report['status'], 'blocked')

    def test_common_setup_rejects_other_flags_before_installation(self):
        import manage
        for flags in [['--check'], ['--tool', 'python-environment'], ['--workflows'], ['--output', 'work/file.zip']]:
            with self.subTest(flags=flags), patch.object(sys, 'argv', ['manage.py', 'setup', *flags]), patch('setup_verification.subprocess.run') as runner:
                with self.assertRaises(SystemExit) as error:
                    manage.main()
                self.assertEqual(error.exception.code, 2)
                runner.assert_not_called()
