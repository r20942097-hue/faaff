import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import setup_verification


class SetupTests(unittest.TestCase):
    def test_global_interpreter_is_blocked_without_installation(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            destination = root / 'catalog/results/python-setup.json'
            destination.parent.mkdir(parents=True)
            destination.write_text('{"passed":true}')
            with patch.object(setup_verification, 'ROOT', root), patch.object(sys, 'prefix', 'base'), patch.object(sys, 'base_prefix', 'base'), patch('setup_verification.subprocess.run') as runner:
                self.assertEqual(setup_verification.main(), 2)
                runner.assert_not_called()
            report = json.loads(destination.read_text(encoding='utf-8'))
            self.assertFalse(report['passed'])
            self.assertEqual(report['status'], 'blocked')

    def test_invalid_lock_prevents_installation_and_invalidates_old_success(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            destination = root / 'catalog/results/python-setup.json'
            destination.parent.mkdir(parents=True)
            destination.write_text('{"passed":true}')
            with patch.object(setup_verification, 'ROOT', root), patch.object(sys, 'prefix', 'virtual'), patch.object(sys, 'base_prefix', 'base'), patch('setup_verification.subprocess.run') as runner:
                self.assertEqual(setup_verification.main(), 1)
                runner.assert_not_called()
            report = json.loads(destination.read_text(encoding='utf-8'))
            self.assertFalse(report['passed'])
            self.assertEqual(report['status'], 'failed')
