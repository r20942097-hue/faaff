"""Create a portable source snapshot using the recovered pack verifier/builder."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
import zipfile

from configuration import load as load_configuration
from registry import safe_path, child_environment


def invoke(command, directory):
    completed = subprocess.run(command, cwd=directory, capture_output=True, text=True, encoding='utf-8', env=child_environment(), timeout=300, check=False)
    if completed.returncode:
        raise ValueError('package verification failed: ' + completed.stdout + completed.stderr)
    return completed.stdout


def compress(source, destination):
    # Preserve the recovered builder's fixed timestamps, paths and file modes.
    with zipfile.ZipFile(source) as incoming, zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as outgoing:
        for member in incoming.infolist():
            outgoing.writestr(member, incoming.read(member), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def package(root, output):
    from manage import scan, build
    root = Path(root).resolve()
    output = Path(output)
    if output.is_absolute():
        try:
            relative = output.relative_to(root).as_posix()
        except ValueError as error:
            raise ValueError('package output must be inside the workspace') from error
    else:
        relative = output.as_posix()
    destination = safe_path(root, relative)
    if destination.suffix != '.zip' or destination.exists():
        raise ValueError('output must be a new .zip file')
    checksum = safe_path(root, relative + '.sha256')
    if checksum.exists():
        raise ValueError('output checksum already exists')
    if not relative.startswith('work/'):
        raise ValueError('package output must be under work/')
    config = load_configuration(root)
    rows = scan(root, config)
    scratch = safe_path(root, 'work/release-build')
    scratch.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=scratch) as directory:
        stage = Path(directory) / 'workspace'
        stage.mkdir()
        for source in config['sources']:
            (stage / source['path']).mkdir(parents=True, exist_ok=True)
        for row in rows:
            source = safe_path(root, row['original'])
            target = stage / row['original']
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            if hashlib.sha256(target.read_bytes()).hexdigest() != row['sha256']:
                raise ValueError('source changed during packaging: ' + row['original'])
        for source in config['sources']:
            source_directory = stage / source['path']
            if not any(source_directory.iterdir()):
                (source_directory / 'README.md').write_text('保存用フォルダです。現在、登録ファイルはありません。\n', encoding='utf-8', newline='')
        config['link_mode'] = 'direct'
        (stage / 'catalog/config.json').write_text(json.dumps(config, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='')
        invoke([sys.executable, 'tools/manage.py', 'doctor'], stage)
        build(stage, config)
        # Validate a clean extracted-layout source snapshot before creating ZIP.
        invoke([sys.executable, 'tools/manage.py', 'test'], stage)
        # The timed execution report is a validation output, not reproducible source.
        (stage / 'catalog/results/latest.json').write_text(json.dumps({
            'passed': True, 'scope': 'Standard checks passed during snapshot construction; execution logs remain outside this ZIP.',
            'checks': [{'name': check['name'], 'exit_code': 0} for check in __import__('registry').load()['checks']]}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='')
        profile = json.loads((root / 's/filter-profiles.json').read_text(encoding='utf-8'))
        (stage / 'SNAPSHOT.json').write_text(json.dumps({
            'schema': 'workspace-source-snapshot/v1', 'filter_version': profile['version'],
            'scope': 'Portable source, configuration and catalogue snapshot. Recording product source and real environment acceptance remain incomplete.',
            'source_files': len(rows), 'link_mode': 'direct', 'source_identity': [
                {'path': row['original'], 'sha256': row['sha256']} for row in rows]}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='')
        # Keep links to prior results usable and preserve their explicit scope.
        reports = root / 'catalog/results'
        for path in sorted(reports.glob('*')):
            if path.is_file() and not path.is_symlink() and path.name not in {'latest.json', 'doctor.json', 'package.json'}:
                shutil.copyfile(path, stage / 'catalog/results' / path.name)
        # The archive cannot embed its own digest. Keep the detached identity
        # separate rather than copying a stale prior package's successful report.
        (stage / 'catalog/results/package.json').write_text(json.dumps({
            'schema': 'portable-snapshot-check/v1', 'passed': True,
            'source_files': len(rows), 'clean_layout_standard_checks': True,
            'artifact_identity': 'Read the detached .zip.sha256 and external package validation record.',
            'scope': 'Source snapshot, not a completed Windows recording distribution.'}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='')
        content = {}
        for path in sorted(stage.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                content[path.relative_to(stage).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
        (stage / 'CONTENT_MANIFEST_SHA256.json').write_text(json.dumps(content, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='')
        artifact = Path(directory) / 'artifact.zip'
        builder = root / 'library-files/tool-sources/portfolio/tools/build_pack.py'
        invoke([sys.executable, str(builder), str(stage), str(artifact)], root)
        # A second build must be byte-identical for this frozen source/report set.
        second = Path(directory) / 'second.zip'
        invoke([sys.executable, str(builder), str(stage), str(second)], root)
        digest = hashlib.sha256(artifact.read_bytes()).hexdigest()
        if digest != hashlib.sha256(second.read_bytes()).hexdigest():
            raise ValueError('package is not reproducible')
        compressed = Path(directory) / 'compressed.zip'
        second_compressed = Path(directory) / 'second-compressed.zip'
        compress(artifact, compressed)
        compress(second, second_compressed)
        original_bytes = artifact.stat().st_size
        digest = hashlib.sha256(compressed.read_bytes()).hexdigest()
        if digest != hashlib.sha256(second_compressed.read_bytes()).hexdigest():
            raise ValueError('compressed package is not reproducible')
        artifact = compressed
        extracted = Path(directory) / 'extracted'
        from extract_snapshot import extract
        extract(artifact, digest, extracted)
        invoke([sys.executable, str(root / 'library-files/tool-sources/portfolio/tools/verify_pack.py'), str(extracted)], root)
        invoke([sys.executable, 'tools/manage.py', 'check'], extracted)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as stream, artifact.open('rb') as incoming:
            shutil.copyfileobj(incoming, stream)
    with checksum.open('x') as stream:
        stream.write(digest + '  ' + destination.name + '\n')
    report = {'schema': 'portable-snapshot-check/v1', 'passed': True, 'sha256': digest,
              'file': relative, 'source_files': len(rows), 'reproducible_frozen_inputs': True,
              'compression': 'ZIP_DEFLATED level 9', 'uncompressed_zip_bytes': original_bytes,
              'compressed_zip_bytes': destination.stat().st_size,
              'clean_layout_standard_checks': True, 'extracted_hashes': True, 'extracted_catalogue_check': True,
              'portable_paths_checked_before_extraction': True,
              'scope': 'Source snapshot, not a completed Windows recording distribution.'}
    (root / 'catalog/results/package.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0
