"""Verify selected upstream tool sources against their recorded identities."""
import hashlib
import json
from pathlib import Path
import re

from registry import load_json, safe_path

ROOT = Path(__file__).resolve().parents[1]


def inspect(directory):
    directory = Path(directory).resolve()
    origin = load_json(safe_path(directory, 'SOURCE-ORIGIN.json'))
    if not isinstance(origin, dict):
        raise ValueError('source origin must be an object')
    for key, pattern in [('repository', r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+'),
                         ('commit', r'[0-9a-f]{40}'), ('archive_sha256', r'[0-9a-f]{64}')]:
        if not isinstance(origin.get(key), str) or not re.fullmatch(pattern, origin[key]):
            raise ValueError('invalid origin identity: ' + key)
    records = origin.get('files')
    if not isinstance(records, list) or not records:
        raise ValueError('source file identities missing')
    expected = set()
    mismatches = []
    for item in records:
        if not isinstance(item, dict):
            raise ValueError('invalid source file record')
        path = safe_path(directory, item.get('path'))
        name = item['path']
        if name in expected or name == 'SOURCE-ORIGIN.json':
            raise ValueError('duplicate or self-referential source identity')
        expected.add(name)
        digest = item.get('sha256')
        if not isinstance(digest, str) or not re.fullmatch('[0-9a-f]{64}', digest):
            raise ValueError('invalid source hash')
        actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        if actual != digest:
            mismatches.append({'path': name, 'expected': digest, 'actual': actual})
    extra = []
    for path in directory.rglob('*'):
        relative = path.relative_to(directory).as_posix()
        if '__pycache__' in path.parts or '.pytest_cache' in path.parts:
            continue
        if path.is_symlink():
            raise ValueError('symlink in selected source: ' + relative)
        if path.is_file() and relative != 'SOURCE-ORIGIN.json' and relative not in expected:
            extra.append(relative)
    return {'repository': origin['repository'], 'commit': origin['commit'],
            'recorded_archive_sha256': origin['archive_sha256'], 'files': len(expected),
            'passed': not mismatches and not extra, 'mismatches': mismatches, 'unrecorded_files': sorted(extra)}


def main():
    records = [inspect(safe_path(ROOT, 'library-files/tool-sources/' + name)) for name in ['portfolio', 'security']]
    report = {'schema': 'selected-tool-source-check/v1', 'passed': all(item['passed'] for item in records),
              'scope': 'Selected source hashes and file inventory. Recorded identities are local trust inputs; this is not a signature, vulnerability or product acceptance check.',
              'sources': records}
    safe_path(ROOT, 'catalog/results/tool-sources.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, OSError) as error:
        raise SystemExit('ERROR: ' + str(error))
