from datetime import date, timedelta
import unittest

import validate_candidate_evidence as ev


class EvidenceValidatorTests(unittest.TestCase):
    def test_repository_evidence_is_valid(self):
        manifest = ev.load_json(ev.MANIFEST_PATH)
        queue = ev.load_json(ev.ROOT / manifest['candidate_queue'])
        errors, _warnings = ev.validate(today=ev.parse_iso_date(queue['observed_at']))
        self.assertEqual(errors, [])

    def test_repository_evidence_is_rejected_before_observation(self):
        manifest = ev.load_json(ev.MANIFEST_PATH)
        queue = ev.load_json(ev.ROOT / manifest['candidate_queue'])
        observed = ev.parse_iso_date(queue['observed_at'])
        errors, _ = ev.validate(today=observed - timedelta(days=1))
        self.assertTrue(any('future' in error for error in errors))

    def test_repository_evidence_expires(self):
        manifest = ev.load_json(ev.MANIFEST_PATH)
        queue = ev.load_json(ev.ROOT / manifest['candidate_queue'])
        observed = ev.parse_iso_date(queue['observed_at'])
        errors, _ = ev.validate(today=observed + timedelta(days=manifest['candidate_evidence_max_age_days'] + 1))
        self.assertTrue(any('stale' in error for error in errors))

    def test_parse_iso_date(self):
        self.assertEqual(ev.parse_iso_date("2026-10-01"), date(2026, 10, 1))
        self.assertIsNone(ev.parse_iso_date("2026-1-1"))
        self.assertIsNone(ev.parse_iso_date("not-a-date"))
        self.assertIsNone(ev.parse_iso_date(None))

    def test_freshness_boundary(self):
        today = date(2026, 11, 15)
        self.assertFalse(ev.evidence_is_stale(date(2026, 10, 1), today, 45))
        self.assertTrue(ev.evidence_is_stale(date(2026, 9, 30), today, 45))

    def test_immutable_snapshot_shape(self):
        url = (
            "https://github.com/easylist/easylist/blob/"
            "de1806065e53df5732bd048688a9b2800fa69a73/"
            "easyprivacy/easyprivacy_trackingservers_general.txt"
        )
        match = ev.GITHUB_FILE_SNAPSHOT_RE.fullmatch(url)
        self.assertIsNotNone(match)
        self.assertEqual(match.group(3), "de1806065e53df5732bd048688a9b2800fa69a73")

    def test_mutable_branch_url_is_not_snapshot(self):
        url = (
            "https://github.com/easylist/easylist/blob/master/"
            "easyprivacy/easyprivacy_trackingservers_general.txt"
        )
        self.assertIsNone(ev.GITHUB_FILE_SNAPSHOT_RE.fullmatch(url))


if __name__ == "__main__":
    unittest.main()
