# 広告ブロック更新・統合一覧

更新日：2026-10-11。広告・追跡リストは **20261011.1** に更新しました。GitHubの更新ブランチとPR（s #3・faaff #14）へ反映済みです。s #3はmainへ反映済みで購読先も更新済みです。faaff #14は2026-10-12にDependency Reviewも合格し、main未反映です。

[ブラウザー向け比較表](generated/filters.html) · [全ファイルの検索一覧](generated/inventory.html) · [ライブラリ一覧](generated/libraries.html)

## 最初に見る表

| 選ぶもの | ファイル | 有効ネットワークルール | 用途 |
|---|---|---:|---|
| 現行・広告 | [s/ad.txt](../s/ad.txt) | 18 | 基本リストと併用。uBOは拡張もinclude |
| 現行・広告の共通版 | [faaff広告](../faaff/browser_filter_lists/filters/universal-web-ad-filter.txt) | 17 | sと共通17ルール |
| 現行・任意追跡 | [s/tracking.txt](../s/tracking.txt) / [faaff追跡](../faaff/browser_filter_lists/filters/universal-web-tracking-filter.txt) | 各9 | 有効ルールは同一 |
| v2・広告候補 | [v2/ad.txt](../s/v2/ad.txt) | 93 | 世界・地域向けの広い候補 |
| v2・追跡候補 | [v2/tracking.txt](../s/v2/tracking.txt) | 38 | 任意。互換性確認が必要 |
| v2・Strict | [v2/strict.txt](../s/v2/strict.txt) | 13 | 高い影響があり得る任意追加 |
| uBO専用拡張 | [ad-ubo.txt](../s/ad-ubo.txt) | — | スポンサー表示・Twitchの限定通信とUI |
| 外部Twitch拡張 | [twitch-custom-optional.txt](../s/twitch-custom-optional.txt) | — | 既定では無効。外部リソースが必要 |

通常は保守されている基本リストと現行広告版から使います。追跡版は任意です。v2とStrictは候補であり、現行版への自動統合はしていません。sとfaaffの同じ共通リストを両方登録する必要はありません。

日本語フォントの標準版・Deepは広告ブロックとは別です。標準版は本文中心、Deepは標準版を含み、子要素まで調べます。Deepは標準版で残る文字だけを調整したい場合に選びます。初回の広告更新では変更しませんでしたが、実拡張で既定設定時にスタイルが効かない問題を確認し、明示的な全ホスト指定（`*##`）へ修正しました。両方20261011.1です。フォントの対象・アイコン保護・行高は維持しています。修正は[s PR #5](https://github.com/r20942097-hue/s/pull/5)に保存し、CI成功を確認しました。main未反映です。

## 変更の比較

| 対象 | 更新前 | 更新後・理由 |
|---|---|---|
| s広告のa-ads | 親と子の2ルール | 親1ルールへ統合。子も遮断されることを検証 |
| v2広告 | 95 | 93。親でカバーする冗長ルールとAmazonの広い遮断を除外 |
| v2追跡 | 40 | 38。広いNew Relic/SentryはStrictへ移動 |
| Strict | 11 | 13。広いSDKドメインを任意に分離 |
| Twitch通信 | 構文だけでは動作を確かめられない | 実関数で検証。対象ホストのみ遮断する正規表現へ修正 |
| Twitch外部リソース | 既定リストに混在 | 追加設定が必要な任意ファイルへ分離 |
| 共通リスト管理 | sとfaaffで別々に編集 | 共通JSONから7つの配信ファイルを生成 |
| 候補証拠 | 10月初旬の資料 | 10月11日に取得・照合した固定資料で再確認 |
| 候補状態 | 1候補・4保留 | 維持。実サイト影響が未確認なので採用を増やさない |

Amazonの判断根拠は現在のAdGuard例外・uAssets unbreakです。[候補の詳細](../faaff/browser_filter_lists/experimental/CANDIDATES.md)に固定コミットの参照を記録しました。

## 検証結果と読み方

| 検証 | 結果 | 何を確認したか |
|---|---|---|
| 回帰テスト | 271件通過・1件skip | フィルター・共通管理・取得した管理ツールを再実行。Windows junctionは未実施 |
| 共通コマンド | 17標準＋4追加検査 | 静的・回帰・原本整合性・実エンジン・画面・CI設定 |
| 実エンジン2種類 | 1,190通信ケース通過 | uBO/Ghosteryで第三者通信・同一サイト・子ドメイン・名前の境界・種類・例外 |
| uBOスクリプトレット | 6ケース通過 | 実組み込み関数で対象ホスト遮断、似たホスト・再生用通信の通過 |
| 合成画面 | 12項目通過 | 9言語スポンサー、通常リンク保持、日本語フォント・アイコン・行高、5,000要素 |
| 上流監査 | 145ドメイン・20資料 | 全資料のSHA256を照合。分類参照・例外参照・未判定を一覧化 |
| 公開ページ | 6サイト×4設定 | TLS検証を保つ中継でネットワークと基本表示を比較 |
| 一覧の画面 | 31項目通過 | 検索・原本リンク・比較表・ライブラリ・ツール表・スマートフォン表示 |
| Firefox実拡張 | 12項目通過 | 署名付きuBO、通信境界、スポンサー表示、日本語標準・Deep |
| CI設定 | 5ワークフロー | 構造、重複キー、固定SHA、権限、時間制限 |

上流参照は72ドメインが分類参照のみ、70が例外・互換性参照あり、3が選択した資料では参照なしでした。これは自動的な安全/危険の判定ではありません。例外は特定のサイト・パス・種類に限定される場合があるため、個別確認が必要です。

[ドメイン別CSV](results/upstream-audit.csv)を表計算ソフトで開くと、ルール群と参照数で絞り込めます。[詳細JSON](results/upstream-audit.json)には該当ルールと上流の行リンクがあります。

### 公開ページの確認範囲

| サイト | 観察 | 判定の限界 |
|---|---|---|
| NoSub | 全設定で本文・59リンク・video要素2を確認 | 動画の再生/ダウンロード操作は未確認 |
| BBC | 全設定で本文・250リンクを確認 | 動画・フォーム操作は未確認 |
| Stack Overflow | 全設定で本文・227リンクを確認 | ログイン・投稿は未確認 |
| Yahoo!ニュース | 見出し・リンクを確認 | 通信失敗/403/ページエラーがあり、完全な互換性判定は保留 |
| Twitch | ページシェルを確認 | GET/HEADのみの検査。API・ログイン・再生の判定は保留 |
| CNN | 短い応答しか取得できず | 本文が評価できないため判定不能 |

ネットワーク比較は基本EasyList＋EasyPrivacy、現行追加、v2追加、Strict追加の4設定です。通信応答のキャッシュは比較間で再利用しましたが、サイトには動的差があります。広告表示や全機能の保証にはしません。初回のPlaywrightによる拡張検証はタイムアウトしました。その後、固定Docker image内のFirefox 153＋Geckodriver＋Mozilla署名付きuBO 1.75.0で再検証し、12項目を通過しました。[現在の実拡張結果](results/filter-extension-current.json)を参照してください。外部通信を行わないローカルfixtureです。ログイン・実サイト動画再生・Windows録画のE2Eは未実施です。

## 統合ツールの使い方

`/workspace`で実行します。

```sh
# 生成データの差異だけ確認
python tools/manage.py filters --check

# 共通データから生成し、一覧と標準検査を更新
python tools/manage.py all

# 初回：固定したエンジンとPSLを取得・ハッシュ照合
python s/scripts/prepare_engine.py --directory work/filter-engine

# 実エンジンを含めて検証
python tools/manage.py all --engine-dir work/filter-engine

# 任意：固定した第2エンジンも用意
npm ci --prefix s/verification/ghostery --ignore-scripts --no-audit --no-fund

# PlaywrightとPyYAMLがある環境では画面とCI設定も含める
python tools/manage.py all --engine-dir work/filter-engine --browser --workflows
```

任意の画面・CI検査は`tools/requirements-verification.lock.txt`で直接・間接依存と配布ハッシュを固定しています。2エンジン検証では上のallコマンドに`--ghostery-entry s/verification/ghostery/node_modules/@ghostery/adblocker/dist/esm/index.js`を追加します。

標準生成・検査はPythonの標準ライブラリで動きます。実エンジンはNode.js 24、画面検査はPlaywright/Chromium、CI構造検査はPyYAMLを使います。ブラウザーは専用のworkキャッシュへ置きます。初回の取得にはネットワーク接続が必要です。

上流監査の再実行：

```sh
python s/scripts/audit_upstream.py --cache work/upstream-audit --fetch --report catalog/results/upstream-audit.json --csv catalog/results/upstream-audit.csv
```

このコマンドは固定済み資料を照合します。新しい上流状態を確認するには、公式資料を実際に取得・レビューして固定情報を更新します。チェック日だけを自動的に新しくする機能は設けていません。

## 採用した統合案・次の改良案

共通データは1か所、配信ファイルとGit履歴は既存の場所に維持します。ライセンスが違うCC0の現行版とGPLのv2は混ぜません。候補審査はfaaff、共通生成と実エンジン検査はs、全体実行と一覧はtoolsにまとめました。

次は拡張機能での実操作テスト、両repoのCI実行・公開、ドメイン別の互換性確認へ進めます。録画ツール本体はこの環境にないため、録画機能との実行時統合やWindows E2Eは未完了です。

## GitHub更新状況

- [s #3](https://github.com/r20942097-hue/s/pull/3)：最終コミットのフィルターCI成功。ユーザーの明示的承認後、mainへ反映済み。購読URLの主要6ファイルを照合済み。
- [faaff #14](https://github.com/r20942097-hue/faaff/pull/14)：フィルター検証・CI・CodeQL成功。Dependency Reviewも2026-10-12の失敗ジョブ再実行で成功。
- [Dependency Review再検証](https://github.com/r20942097-hue/faaff/actions/runs/38125486938)：以前のAPI403は再現せず合格。設定値や変更者を直接確認したという意味ではありません。
- 全55パスの内容をGitHubのGit blob SHAとローカルで照合し、一致を確認しました。
- [s #5](https://github.com/r20942097-hue/s/pull/5)：日本語スタイルの既定設定時の不具合を修正。CI成功、main未反映。
- Firefox実拡張のダッシュボード保存・リロードと12動作項目を検証済み。ログイン・実動画再生は未実施。

s #3は、ユーザーからmain反映の明示的承認を受けた後、通常のGitHubマージ操作で反映しました。
