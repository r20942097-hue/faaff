# Python互換性・改善一覧

2026-10-11。Python 3.15は正式版3.15.0を使用します。RC版の結果は正式版の合格数へ算入しません。

| 対象 | 導入方法・改善 | 検証範囲 |
|---|---|---|
| Python 3.11 / 3.14 | 固定依存の配布バイナリをSHA256照合して導入 | Linux・Windowsのソース管理CI |
| Python 3.15 | 同じ通常依存の版を維持、PyYAMLのみ固定ソースから標準Python版を構築 | 正式版3.15.0で標準17検査・Suite26テスト・一覧UI34検査 |
| PyYAML 6.0.3 | cp315バイナリ未提供のためC拡張を使わない | 実際のimport・safe_load・ワークフロー検査 |
| ビルド依存 | setuptools 84.0.0、wheel 0.48.0、packaging 26.3を版・配布SHA256で固定 | 通常依存との版競合を検出、導入後にも版照合 |
| 導入入口 | tools/setup_verification.pyに統合 | 新規仮想環境のみ、ハッシュ照合・pip check・版照合・結果保存 |
| 子プロセス出力 | 不正なUTF-8をエスケープして保存 | 失敗の終了コードと診断結果を保持する回帰テスト |
| 過去の合格表示 | 登録入力・実行設定・Python版を照合 | ファイル変更・設定変更・実行中変更・別Python版で再検証表示 |

## 導入と見方

```sh
python -m venv work/verification-venv
# Linux/macOS
work/verification-venv/bin/python tools/setup_verification.py
# Windows
work/verification-venv/Scripts/python.exe tools/setup_verification.py
```

新しい仮想環境で実行してください。既存C拡張版のPyYAMLが残る環境では標準Python版の確認に失敗するため、新規環境を作成します。グローバルPythonでの導入は停止します。プロキシ設定を引き継ぎ、キャッシュはwork/に保存します。

導入後、仮想環境のPythonで`tools/manage.py doctor`を実行し、[ツール一覧](generated/tools.html)を開きます。前回の合格欄の小さい説明は、登録入力・実行設定・Python版が一致しているかを示します。外部サービスや未登録の間接入力・全てのバイナリまで同一と保証する意味ではありません。

導入ログは[python-setup.json](results/python-setup.json)、実行版照合は[python-environment.json](results/python-environment.json)、正式版取得根拠は[python315.json](results/python315.json)で確認できます。複数環境で同じテストを実行しても、合格数を重複加算しません。

## 調査根拠と次の改善

- [Python 3.15.0正式版](https://www.python.org/downloads/release/python-3150/)：2026-10-09公開。
- [PyYAML 6.0.3配布情報](https://pypi.org/pypi/PyYAML/6.0.3/json)：cp315バイナリがなく、binary-only導入の失敗を再現。
- [PyYAMLの構築設定](https://github.com/yaml/pyyaml/blob/6.0.3/setup.py)：C拡張を無効化する公式設定を使用。
- [子プロセスのencoding/errors](https://docs.python.org/3.15/library/subprocess.html)：出力の復号エラー処理を明示。

固定するのは取得したソースとビルド依存の配布ハッシュです。構築したPyYAML wheelのバイト単位の再現性までは保証しません。通常のPython 3.15で確認しており、free-threaded版・実録画・Windows製品の操作試験は別の検証が必要です。

今後cp315バイナリが提供された時点で、提供元・SHA256・Linux/Windowsの6環境CIを照合して構築手順の簡素化を検討します。標準Python版はC拡張版より処理速度が低い可能性があるため、大容量YAMLの実測が必要になった場合は専用ベンチマークを追加します。
