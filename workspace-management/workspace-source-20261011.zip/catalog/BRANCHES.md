# ブランチと取得済みツール一覧

2026-10-11に16ブランチを確認しました。取得したソースは固定コミットとアーカイブSHA256を記録しています。mainや他の作業ブランチは上書きしていません。

| ブランチ | ファイル | Python | 取り扱い |
|---|---:|---:|---|
| [browser-filter-cross-source-gates](https://github.com/r20942097-hue/faaff/tree/ce0e8571f5797ee62e4d1c5685e7cae196450560) | 32 | 7 | 構成を確認 |
| [browser-filter-delta-v4](https://github.com/r20942097-hue/faaff/tree/e894b0215100dd740a7bcdb35c250a049b69a19a) | 38 | 9 | 構成を確認 |
| [browser-filter-evidence-hardening](https://github.com/r20942097-hue/faaff/tree/2ef0b4051e10b5a4b4cb8bb060a61b81830dfb55) | 30 | 5 | 構成を確認 |
| [browser-filter-lists-hardening](https://github.com/r20942097-hue/faaff/tree/69d5fb36326f4ab39b4ee711d19cbe85c219062b) | 26 | 2 | 構成を確認 |
| [browser-filter-lists-polish](https://github.com/r20942097-hue/faaff/tree/97cd7a5a49573109f7e90bc8edf7d3afb08f9d4f) | 21 | 1 | 構成を確認 |
| [browser-filter-lists-publish](https://github.com/r20942097-hue/faaff/tree/dff28efed202204ba980dfa559870a40b9d6bc92) | 21 | 1 | 構成を確認 |
| [codex/control-plane-v9.1-completion-2026-10-05](https://github.com/r20942097-hue/faaff/tree/7f030dbf13aebacba3016528f22f87bfd7c2663d) | 97 | 34 | 選択した管理・監査ソースを取得 |
| [codex/delta-v4-canary-empty-test-fix](https://github.com/r20942097-hue/faaff/tree/64cf03a41529d885ed15116d3db5d1d2bbbc1837) | 42 | 11 | 選択した管理・監査ソースを取得 |
| [codex/project-index-2026-10-05](https://github.com/r20942097-hue/faaff/tree/a321cb9f1a6975ed4fa98ddd6680f23cac2b86a5) | 75 | 21 | 構成を確認 |
| [codex/ucs-control-plane-phase2](https://github.com/r20942097-hue/faaff/tree/49bd723de2aeb199fb7e5e2b0c34e69ddba1dc79) | 30 | 5 | 構成を確認 |
| [codex/ucs-control-plane-phase3-security](https://github.com/r20942097-hue/faaff/tree/dea95bb1f3610ec6e7b04a3e0f65544e9c33f8d6) | 44 | 13 | 選択した管理・監査ソースを取得 |
| [codex/universal-control-suite](https://github.com/r20942097-hue/faaff/tree/b49dd9f13a97e6f96faf879ec5547c3fbb03ed51) | 22 | 3 | 構成を確認 |
| [codex/update-tools-20261011](https://github.com/r20942097-hue/faaff/tree/c00d72829bdb772ba4db18cded78c1838ec0f254) | 35 | 9 | 構成を確認 |
| [dependabot/github_actions/actions/checkout-7](https://github.com/r20942097-hue/faaff/tree/9dbe385037b3445f915dd0286bf51b2f92edc120) | 32 | 7 | 構成を確認 |
| [dependabot/github_actions/actions/setup-python-7](https://github.com/r20942097-hue/faaff/tree/d3b12dd7fbedd38c5d49907c91c7c231e567195c) | 32 | 7 | 構成を確認 |
| [main](https://github.com/r20942097-hue/faaff/tree/873f7bd5dc68443e2ef0d49a458f0222af6f588d) | 32 | 7 | 構成を確認 |

取得・登録したコードは library-files/tool-sources/portfolio と security に保存しています。壊れた旧bootstrapは登録対象から除外しました。広告リストの旧版を別ブランチから上書きしていません。

Control Plane v9.1は16ファイルの固定ハッシュで抽出して検証します。Control Plane Nextは23ファイルのZIPと内外のハッシュ一覧を検証し、同じバイト列へ再構築できることを確認します。

記録された製品バージョンや過去のPASSは履歴です。現在のローカル実機検証へ引き継ぎません。
