# 他のツール・製品の統合案

[検索できる製品一覧](generated/projects.html) · [Markdown表](generated/projects.md) · [CSV一覧](generated/projects.csv) · [原本JSON](projects.json)

履歴の参照版と現在の本体ソース・検証状況を分けています。管理・監査コードの合格は、録画・AI・Windows操作など製品本体の完成判定には使いません。
