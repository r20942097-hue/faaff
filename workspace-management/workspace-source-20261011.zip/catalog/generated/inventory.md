# ライブラリ・成果物カタログ

登録ファイル：**185件**。`python tools/manage.py build` で更新します。

録画ツールの実行ソース・ZIP、Windows実機テストは未確認。状態はローカル確認に基づきます。

| 出典 | ファイル数 |
|---|---:|
| catalog-docs | 9 |
| downloads | 1 |
| faaff | 35 |
| library-files | 75 |
| management | 33 |
| s | 31 |
| workspace-docs | 1 |

## catalog-docs

| 分類 | ファイル | 状態 | バージョン |
|---|---|---|---|
| 資料 | [ADBLOCK-UPDATE.md](../../catalog/ADBLOCK-UPDATE.md) | 資料・設定 | — |
| 資料 | [BRANCHES.md](../../catalog/BRANCHES.md) | 資料・設定 | — |
| 資料 | [INTEGRATION.md](../../catalog/INTEGRATION.md) | 資料・設定 | — |
| 資料 | [PROJECTS.md](../../catalog/PROJECTS.md) | 資料・設定 | — |
| 資料 | [README.md](../../catalog/README.md) | 資料・設定 | — |
| 資料 | [REPORT.md](../../catalog/REPORT.md) | 資料・設定 | — |
| 資料 | [TOOLS.md](../../catalog/TOOLS.md) | 資料・設定 | — |
| 資料 | [config.json](../../catalog/config.json) | 資料・設定 | — |
| 資料 | [projects.json](../../catalog/projects.json) | 資料・設定 | — |

## downloads

| 分類 | ファイル | 状態 | バージョン |
|---|---|---|---|
| ライブラリ・資料 | [README.md](../../shared/downloads/README.md) | 資料・設定 | — |

## faaff

| 分類 | ファイル | 状態 | バージョン |
|---|---|---|---|
| CI・保守 | [.github/dependabot.yml](../../faaff/.github/dependabot.yml) | 資料・設定 | — |
| CI・保守 | [.github/workflows/ci.yml](../../faaff/.github/workflows/ci.yml) | 資料・設定 | — |
| CI・保守 | [.github/workflows/codeql.yml](../../faaff/.github/workflows/codeql.yml) | 資料・設定 | — |
| CI・保守 | [.github/workflows/dependency-review.yml](../../faaff/.github/workflows/dependency-review.yml) | 資料・設定 | — |
| CI・保守 | [.github/workflows/validate-browser-filter-lists.yml](../../faaff/.github/workflows/validate-browser-filter-lists.yml) | 資料・設定 | — |
| 資料 | [.gitignore](../../faaff/.gitignore) | 資料・設定 | — |
| 資料 | [CHANGELOG.md](../../faaff/CHANGELOG.md) | 資料・設定 | — |
| 資料 | [GITHUB-READY.md](../../faaff/GITHUB-READY.md) | 資料・設定 | — |
| 資料 | [PRODUCTION-E2E-CHECKLIST.md](../../faaff/PRODUCTION-E2E-CHECKLIST.md) | 資料・設定 | — |
| 資料 | [README.md](../../faaff/README.md) | 資料・設定 | — |
| 資料 | [SECURITY-SCAN-STATUS.md](../../faaff/SECURITY-SCAN-STATUS.md) | 資料・設定 | — |
| 資料 | [SECURITY.md](../../faaff/SECURITY.md) | 資料・設定 | — |
| 資料 | [SHA256-v6.10.0.txt](../../faaff/SHA256-v6.10.0.txt) | 資料・設定 | — |
| 資料 | [SOURCE-SYNC.md](../../faaff/SOURCE-SYNC.md) | 資料・設定 | — |
| 資料 | [VERIFICATION.md](../../faaff/VERIFICATION.md) | 資料・設定 | — |
| 資料 | [browser_filter_lists/CHANGELOG.md](../../faaff/browser_filter_lists/CHANGELOG.md) | 資料・設定 | — |
| 資料 | [browser_filter_lists/POLICY.md](../../faaff/browser_filter_lists/POLICY.md) | 資料・設定 | — |
| 資料 | [browser_filter_lists/README.md](../../faaff/browser_filter_lists/README.md) | 資料・設定 | — |
| 案内ページ | [browser_filter_lists/docs/index.html](../../faaff/browser_filter_lists/docs/index.html) | 資料・設定 | — |
| 実験候補 | [browser_filter_lists/experimental/CANDIDATES.md](../../faaff/browser_filter_lists/experimental/CANDIDATES.md) | 実験候補 | — |
| 実験候補 | [browser_filter_lists/experimental/candidates.json](../../faaff/browser_filter_lists/experimental/candidates.json) | 実験候補 | — |
| フィルター | [browser_filter_lists/filters/universal-web-ad-filter.txt](../../faaff/browser_filter_lists/filters/universal-web-ad-filter.txt) | 現行 | 20261011.1 |
| フィルター | [browser_filter_lists/filters/universal-web-tracking-filter.txt](../../faaff/browser_filter_lists/filters/universal-web-tracking-filter.txt) | 現行 | 20261011.1 |
| 資料 | [browser_filter_lists/manifest.json](../../faaff/browser_filter_lists/manifest.json) | 資料・設定 | — |
| 検証・管理コード | [browser_filter_lists/scripts/registry_io.py](../../faaff/browser_filter_lists/scripts/registry_io.py) | 資料・設定 | — |
| 検証・管理コード | [browser_filter_lists/scripts/render_candidate_report.py](../../faaff/browser_filter_lists/scripts/render_candidate_report.py) | 資料・設定 | — |
| 検証・管理コード | [browser_filter_lists/scripts/test_evidence.py](../../faaff/browser_filter_lists/scripts/test_evidence.py) | 資料・設定 | — |
| 検証・管理コード | [browser_filter_lists/scripts/test_promotion.py](../../faaff/browser_filter_lists/scripts/test_promotion.py) | 資料・設定 | — |
| 検証・管理コード | [browser_filter_lists/scripts/test_registry_io.py](../../faaff/browser_filter_lists/scripts/test_registry_io.py) | 資料・設定 | — |
| 検証・管理コード | [browser_filter_lists/scripts/test_validator.py](../../faaff/browser_filter_lists/scripts/test_validator.py) | 資料・設定 | — |
| 検証・管理コード | [browser_filter_lists/scripts/validate_candidate_evidence.py](../../faaff/browser_filter_lists/scripts/validate_candidate_evidence.py) | 資料・設定 | — |
| 検証・管理コード | [browser_filter_lists/scripts/validate_candidate_promotion.py](../../faaff/browser_filter_lists/scripts/validate_candidate_promotion.py) | 資料・設定 | — |
| 検証・管理コード | [browser_filter_lists/scripts/validate_filters.py](../../faaff/browser_filter_lists/scripts/validate_filters.py) | 資料・設定 | — |
| ライブラリ設定 | [pyproject.toml](../../faaff/pyproject.toml) | 資料・設定 | — |
| ライブラリ設定 | [requirements.txt](../../faaff/requirements.txt) | 資料・設定 | — |

## library-files

| 分類 | ファイル | 状態 | バージョン |
|---|---|---|---|
| ライブラリ・資料 | [tool-sources/portfolio/PROJECT_INDEX.md](../../library-files/tool-sources/portfolio/PROJECT_INDEX.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/SOURCE-ORIGIN.json](../../library-files/tool-sources/portfolio/SOURCE-ORIGIN.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/.gitattributes](../../library-files/tool-sources/portfolio/control-plane-v9/.gitattributes) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/README.md](../../library-files/tool-sources/portfolio/control-plane-v9/README.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/extract_source.py](../../library-files/tool-sources/portfolio/control-plane-v9/extract_source.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime-manifest.json](../../library-files/tool-sources/portfolio/control-plane-v9/runtime-manifest.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/migrations/009_control_plane_v9.sql](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/migrations/009_control_plane_v9.sql) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/migrations/010_policy_documents.sql](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/migrations/010_policy_documents.sql) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/policies/promotion-policy-v9.json](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/policies/promotion-policy-v9.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/schemas/control-plane.sql](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/schemas/control-plane.sql) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/tools/apply_local_promotion.py](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/tools/apply_local_promotion.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/tools/apply_sql_migration.py](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/tools/apply_sql_migration.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/tools/ci_selftest.py](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/tools/ci_selftest.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/tools/evaluate_promotion_eligibility.py](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/tools/evaluate_promotion_eligibility.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/tools/eventlog_v9.py](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/tools/eventlog_v9.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/tools/load_promotion_policy.py](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/tools/load_promotion_policy.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/tools/migrate_v8_to_v9.py](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/tools/migrate_v8_to_v9.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/tools/plan_promotion.py](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/tools/plan_promotion.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/tools/state_v9.py](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/tools/state_v9.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/tools/static_safety_check.py](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/tools/static_safety_check.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/tools/test_promotion_safety.py](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/tools/test_promotion_safety.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/control-plane-v9/runtime/tools/verify_v9.py](../../library-files/tool-sources/portfolio/control-plane-v9/runtime/tools/verify_v9.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/docs/ARTIFACT_GOVERNANCE.md](../../library-files/tool-sources/portfolio/docs/ARTIFACT_GOVERNANCE.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/docs/MANAGEMENT_README.md](../../library-files/tool-sources/portfolio/docs/MANAGEMENT_README.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/docs/NEXT_ACTIONS.md](../../library-files/tool-sources/portfolio/docs/NEXT_ACTIONS.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/docs/OFFICIAL_REFERENCES.md](../../library-files/tool-sources/portfolio/docs/OFFICIAL_REFERENCES.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/docs/PORTFOLIO_AUDIT.md](../../library-files/tool-sources/portfolio/docs/PORTFOLIO_AUDIT.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/docs/RETENTION_POLICY.md](../../library-files/tool-sources/portfolio/docs/RETENTION_POLICY.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/docs/project_registry.json](../../library-files/tool-sources/portfolio/docs/project_registry.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/policies/promotion-policy.json](../../library-files/tool-sources/portfolio/policies/promotion-policy.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/schemas/evidence.schema.json](../../library-files/tool-sources/portfolio/schemas/evidence.schema.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/schemas/project-registry.schema.json](../../library-files/tool-sources/portfolio/schemas/project-registry.schema.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/schemas/release-manifest.schema.json](../../library-files/tool-sources/portfolio/schemas/release-manifest.schema.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/templates/RELEASE_CHECKLIST.md](../../library-files/tool-sources/portfolio/templates/RELEASE_CHECKLIST.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/templates/RELEASE_MANIFEST.example.json](../../library-files/tool-sources/portfolio/templates/RELEASE_MANIFEST.example.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tests/test_governance.py](../../library-files/tool-sources/portfolio/tests/test_governance.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tests/test_product_archive_audit.py](../../library-files/tool-sources/portfolio/tests/test_product_archive_audit.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tools/audit_product_archives.py](../../library-files/tool-sources/portfolio/tools/audit_product_archives.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tools/build_pack.py](../../library-files/tool-sources/portfolio/tools/build_pack.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tools/cli.py](../../library-files/tool-sources/portfolio/tools/cli.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tools/governance.py](../../library-files/tool-sources/portfolio/tools/governance.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tools/promotion_decision.py](../../library-files/tool-sources/portfolio/tools/promotion_decision.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tools/render_index.py](../../library-files/tool-sources/portfolio/tools/render_index.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tools/retention_plan.py](../../library-files/tool-sources/portfolio/tools/retention_plan.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tools/validate_project_registry.py](../../library-files/tool-sources/portfolio/tools/validate_project_registry.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tools/validate_registry.py](../../library-files/tool-sources/portfolio/tools/validate_registry.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tools/validate_release_manifest.py](../../library-files/tool-sources/portfolio/tools/validate_release_manifest.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tools/verify_pack.py](../../library-files/tool-sources/portfolio/tools/verify_pack.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/portfolio/tools/verify_release.py](../../library-files/tool-sources/portfolio/tools/verify_release.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/PHASE3-STATUS.md](../../library-files/tool-sources/security/PHASE3-STATUS.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/SOURCE-ORIGIN.json](../../library-files/tool-sources/security/SOURCE-ORIGIN.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/SUITE-v0.30-AUDIT.md](../../library-files/tool-sources/security/SUITE-v0.30-AUDIT.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/control_plane_next/CONTROL-PLANE-PHASE2-VERIFICATION.md](../../library-files/tool-sources/security/control_plane_next/CONTROL-PLANE-PHASE2-VERIFICATION.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/control_plane_next/README.md](../../library-files/tool-sources/security/control_plane_next/README.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/control_plane_next/SHA256SUMS.txt](../../library-files/tool-sources/security/control_plane_next/SHA256SUMS.txt) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/control_plane_next/SOURCE-ARCHIVE-SHA256.txt](../../library-files/tool-sources/security/control_plane_next/SOURCE-ARCHIVE-SHA256.txt) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/control_plane_next/build_source_archive.py](../../library-files/tool-sources/security/control_plane_next/build_source_archive.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/control_plane_next/ucs-control-plane-phase2-source.zip](../../library-files/tool-sources/security/control_plane_next/ucs-control-plane-phase2-source.zip) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/control_plane_next/verify_source_archive.py](../../library-files/tool-sources/security/control_plane_next/verify_source_archive.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/phase3_security/README.md](../../library-files/tool-sources/security/phase3_security/README.md) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/phase3_security/dependency_inventory.py](../../library-files/tool-sources/security/phase3_security/dependency_inventory.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/phase3_security/external-source-evidence.json](../../library-files/tool-sources/security/phase3_security/external-source-evidence.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/phase3_security/external_source_evidence.py](../../library-files/tool-sources/security/phase3_security/external_source_evidence.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/phase3_security/gate-c-evidence.json](../../library-files/tool-sources/security/phase3_security/gate-c-evidence.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/phase3_security/gate_c_preflight.py](../../library-files/tool-sources/security/phase3_security/gate_c_preflight.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/phase3_security/product-source-inputs.json](../../library-files/tool-sources/security/phase3_security/product-source-inputs.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/phase3_security/product_source_intake.py](../../library-files/tool-sources/security/phase3_security/product_source_intake.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/release/suite-v0.30-inventory.json](../../library-files/tool-sources/security/release/suite-v0.30-inventory.json) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/tests/test_audit_suite_release.py](../../library-files/tool-sources/security/tests/test_audit_suite_release.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/tests/test_phase3_dependency_inventory.py](../../library-files/tool-sources/security/tests/test_phase3_dependency_inventory.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/tests/test_phase3_external_source_evidence.py](../../library-files/tool-sources/security/tests/test_phase3_external_source_evidence.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/tests/test_phase3_gate_c_preflight.py](../../library-files/tool-sources/security/tests/test_phase3_gate_c_preflight.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/tests/test_phase3_product_source_intake.py](../../library-files/tool-sources/security/tests/test_phase3_product_source_intake.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/tools/__init__.py](../../library-files/tool-sources/security/tools/__init__.py) | 資料・設定 | — |
| ライブラリ・資料 | [tool-sources/security/tools/audit_suite_release.py](../../library-files/tool-sources/security/tools/audit_suite_release.py) | 資料・設定 | — |

## management

| 分類 | ファイル | 状態 | バージョン |
|---|---|---|---|
| 検証・管理コード | [browser_smoke.py](../../tools/browser_smoke.py) | 資料・設定 | — |
| 検証・管理コード | [check_control_plane.py](../../tools/check_control_plane.py) | 資料・設定 | — |
| 検証・管理コード | [check_extension.py](../../tools/check_extension.py) | 資料・設定 | — |
| 検証・管理コード | [check_next_archive.py](../../tools/check_next_archive.py) | 資料・設定 | — |
| 検証・管理コード | [check_python_lock.py](../../tools/check_python_lock.py) | 資料・設定 | — |
| 検証・管理コード | [check_sources.py](../../tools/check_sources.py) | 資料・設定 | — |
| 検証・管理コード | [check_workflows.py](../../tools/check_workflows.py) | 資料・設定 | — |
| 検証・管理コード | [configuration.py](../../tools/configuration.py) | 資料・設定 | — |
| 検証・管理コード | [doctor.py](../../tools/doctor.py) | 資料・設定 | — |
| ライブラリ設定 | [extension-lock.json](../../tools/extension-lock.json) | 資料・設定 | — |
| 検証・管理コード | [extract_snapshot.py](../../tools/extract_snapshot.py) | 資料・設定 | — |
| 検証・管理コード | [filter_browser.py](../../tools/filter_browser.py) | 資料・設定 | — |
| 検証・管理コード | [firefox_extension_probe.py](../../tools/firefox_extension_probe.py) | 資料・設定 | — |
| 検証・管理コード | [manage.py](../../tools/manage.py) | 資料・設定 | — |
| 検証・管理コード | [projects.py](../../tools/projects.py) | 資料・設定 | — |
| ライブラリ設定 | [python-lock.json](../../tools/python-lock.json) | 資料・設定 | — |
| 資料 | [registry.json](../../tools/registry.json) | 資料・設定 | — |
| 検証・管理コード | [registry.py](../../tools/registry.py) | 資料・設定 | — |
| 検証・管理コード | [release.py](../../tools/release.py) | 資料・設定 | — |
| ライブラリ設定 | [requirements-extension.lock.txt](../../tools/requirements-extension.lock.txt) | 資料・設定 | — |
| ライブラリ設定 | [requirements-verification.lock.txt](../../tools/requirements-verification.lock.txt) | 資料・設定 | — |
| ライブラリ設定 | [requirements-verification.txt](../../tools/requirements-verification.txt) | 資料・設定 | — |
| ライブラリ設定 | [selenium-lock.json](../../tools/selenium-lock.json) | 資料・設定 | — |
| 検証・管理コード | [tests/test_configuration.py](../../tools/tests/test_configuration.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_doctor.py](../../tools/tests/test_doctor.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_extension_results.py](../../tools/tests/test_extension_results.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_manage.py](../../tools/tests/test_manage.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_next_archive.py](../../tools/tests/test_next_archive.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_projects.py](../../tools/tests/test_projects.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_python_lock.py](../../tools/tests/test_python_lock.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_registry.py](../../tools/tests/test_registry.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_snapshot.py](../../tools/tests/test_snapshot.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_sources.py](../../tools/tests/test_sources.py) | 資料・設定 | — |

## s

| 分類 | ファイル | 状態 | バージョン |
|---|---|---|---|
| CI・保守 | [.github/dependabot.yml](../../s/.github/dependabot.yml) | 資料・設定 | — |
| CI・保守 | [.github/workflows/japanese-text-softener.yml](../../s/.github/workflows/japanese-text-softener.yml) | 資料・設定 | — |
| 資料 | [.gitignore](../../s/.gitignore) | 資料・設定 | — |
| 資料 | [CHANGELOG.md](../../s/CHANGELOG.md) | 資料・設定 | — |
| 資料 | [README.md](../../s/README.md) | 資料・設定 | — |
| フィルター | [ad-ubo.txt](../../s/ad-ubo.txt) | 現行 | 20261011.1 |
| フィルター | [ad.txt](../../s/ad.txt) | 現行 | 20261011.1 |
| 資料 | [filter-profiles.json](../../s/filter-profiles.json) | 資料・設定 | — |
| フィルター | [japanese-text-softener-deep.txt](../../s/japanese-text-softener-deep.txt) | 現行 | 20261011.1 |
| フィルター | [japanese-text-softener.txt](../../s/japanese-text-softener.txt) | 現行 | 20261011.1 |
| 検証・管理コード | [scripts/audit_upstream.py](../../s/scripts/audit_upstream.py) | 資料・設定 | — |
| 検証・管理コード | [scripts/check_engine.mjs](../../s/scripts/check_engine.mjs) | 資料・設定 | — |
| 検証・管理コード | [scripts/export_browser_fixtures.mjs](../../s/scripts/export_browser_fixtures.mjs) | 資料・設定 | — |
| 検証・管理コード | [scripts/generate_lists.py](../../s/scripts/generate_lists.py) | 資料・設定 | — |
| 検証・管理コード | [scripts/prepare_engine.py](../../s/scripts/prepare_engine.py) | 資料・設定 | — |
| 検証・管理コード | [scripts/validate_lists.py](../../s/scripts/validate_lists.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_engine_preparation.py](../../s/tests/test_engine_preparation.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_generation.py](../../s/tests/test_generation.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_japanese_text_softener.py](../../s/tests/test_japanese_text_softener.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_list_metadata.py](../../s/tests/test_list_metadata.py) | 資料・設定 | — |
| 検証・管理コード | [tests/test_upstream_audit.py](../../s/tests/test_upstream_audit.py) | 資料・設定 | — |
| フィルター | [tracking.txt](../../s/tracking.txt) | 現行 | 20261011.1 |
| フィルター | [twitch-custom-optional.txt](../../s/twitch-custom-optional.txt) | 追加設定が必要 | 20261011.1 |
| 資料 | [v2/README.md](../../s/v2/README.md) | 資料・設定 | — |
| フィルター | [v2/ad.txt](../../s/v2/ad.txt) | 候補 | 20261011.1 |
| フィルター | [v2/strict.txt](../../s/v2/strict.txt) | 候補 | 20261011.1 |
| フィルター | [v2/tracking.txt](../../s/v2/tracking.txt) | 候補 | 20261011.1 |
| 資料 | [verification/engine-lock.json](../../s/verification/engine-lock.json) | 資料・設定 | — |
| ライブラリ設定 | [verification/ghostery/package-lock.json](../../s/verification/ghostery/package-lock.json) | 資料・設定 | — |
| ライブラリ設定 | [verification/ghostery/package.json](../../s/verification/ghostery/package.json) | 資料・設定 | — |
| 資料 | [verification/upstream-snapshots.json](../../s/verification/upstream-snapshots.json) | 資料・設定 | — |

## workspace-docs

| 分類 | ファイル | 状態 | バージョン |
|---|---|---|---|
| 資料 | [README.md](../../README.md) | 資料・設定 | — |
