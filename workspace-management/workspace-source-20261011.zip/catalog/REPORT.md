# 全体整理・統合・改良レポート

2026-10-11。[目的別のツール表](generated/tools.html)、[全ファイル一覧](generated/inventory.html)、[ライブラリ表](generated/libraries.html)、[10製品の現状](PROJECTS.md)から確認できます。

## 今回の成果

10製品の[検索・状態絞り込み付き一覧](generated/projects.html)と[CSV](generated/projects.csv)を追加しました。本体ソースの有無と、履歴・現在のE2Eを分けて確認できます。GitHub参照はローカル原本と照合した固定コミットへ揃えています。[66ファイルの照合記録](results/source-publication-match.json)を参照してください。

| 対象 | 結果 | 確認範囲 |
|---|---|---|
| 共通入口 | 15機能を登録 | 実行・診断・時間制限・結果保存を同じ設定で管理 |
| 一覧・整理 | HTML・CSV・Markdown・JSONを生成 | 検索、分類、原本リンク、SHA256、スマートフォン表示 |
| 管理ツールの復元 | 16ブランチを調査、2固定コミットから73ファイルを選択 | 取得元とハッシュ記録、変更・欠落・未登録コードを検出 |
| Control Plane / Suite | 管理・監査の検証を共通入口へ接続 | v9、Next、プロジェクト監査、根拠確認、Suite監査 |
| Python環境 | 版・配布ハッシュを固定 | 通常検証11依存、Linux実拡張15依存、重複をまとめたライブラリ表39件 |
| 文字コード・設定 | UTF-8と改行を明示 | 非UTF-8ロケールでも標準検証通過。子プロセスの出力もUTF-8で統一 |
| 配布 | 圧縮されたソーススナップショット | 固定入力の二重ビルド一致、展開前のハッシュ・パス検査、新規展開後の一覧整合 |
| 広告リスト | 20261011.1、sのmain公開済み | 共通JSON、7配信ファイル、2エンジン1,190通信ケース |
| 日本語表示 | uBO既定設定の問題を修正 | 実拡張で標準・Deepの動作確認。PR #5、CI成功、main未反映 |
| Firefox実拡張 | 12動作項目通過 | 署名付きuBOと固定Docker環境、ローカルfixture。ログイン・実動画再生は対象外 |
| 録画・AI・Windows等の製品 | 本体未取得 | 既存履歴を完成判定へ転用しない。実機テスト未実施 |

## 2つのリポジトリの違い

| 比較 | s | faaff |
|---|---|---|
| 主な役割 | フィルター配信・日本語表示 | 録画資料、候補審査、管理・監査ブランチ |
| 現行広告 | 共通17＋a-ads、uBO拡張 | 共通17の通信ルール |
| 現行追跡 | 9 | 同じ9 |
| 独自機能 | 日本語標準・Deep、v2、Strict | 根拠期限、独立ソース、昇格条件、管理ツール |
| Git履歴・購読URL | 独立、維持 | 独立、維持 |

共通ルールは` s/filter-profiles.json `から生成します。リポジトリ全体は用途と履歴が違うため、それぞれの配信パスを維持し、共通管理を上に置きました。CC0の現行版とGPLのv2は別プロファイルです。

## フォルダの見方

| 場所 | 用途 |
|---|---|
| s/、faaff/ | 原本と独立Git履歴 |
| tools/ | 共通実行・診断・検証・配布 |
| library-files/tool-sources/ | 固定した管理・監査ソースと取得記録 |
| catalog/generated/ | 検索・ツール・ライブラリ・フィルター一覧 |
| catalog/results/ | 今回の検証結果と調査根拠 |
| catalog/artifacts/等 | ローカル環境では原本への分類リンク |
| shared/downloads/ | 保存用。現在登録ファイルなし |
| work/ | 仮想環境、取得キャッシュ、ブラウザー、調査、配布ZIP |

配布ZIPでは分類用symlinkを使わず、一覧から原本を直接開きます。元の2リポジトリを再びコピーして保守するための新しい正本にはしません。保存時点のソーススナップショットです。

## 検証記録

標準17項目と追加4項目が通過しました。回帰テストは標準の245件とSuite監査の26件、計271件通過です。NextのWindows junction 1件はskipとして別に数えます。

- [共通回帰・静的・追加検査](results/latest.json)：各項目の結果とログ
- [Python版照合](results/python-environment.json)
- [取得ツール73ファイルの照合](results/tool-sources.json)
- [Control Plane](results/control-plane.json) / [Suite監査](results/tool-suite-audit.json)
- [実エンジン](results/filter-engine.json)：218ルール、1,190通信、6組込みscriptletケース
- [一覧UI](results/browser.json)：31項目 / [合成DOM](results/filter-browser.json)：12項目
- [現在のFirefox実拡張](results/filter-extension-current.json)：12項目
- [上流145ドメイン・20固定資料](results/upstream-audit.csv)
- [配布パッケージ検証](results/package.json)
- [GitHub更新状況](results/publication.json)

NextのWindows junctionテストは明示的に未実施です。録画資料の過去の「441テスト合格」等は今回の再実行数に含めません。古い取得ソースの検証記録も履歴として区別します。

## 公開と残課題

[s #3](https://github.com/r20942097-hue/s/pull/3)はユーザー承認後にmainへ反映し、主要6購読ファイルを照合しました。[s #5](https://github.com/r20942097-hue/s/pull/5)は日本語表示の追補修正で、CI成功、main未反映です。

[faaff #14](https://github.com/r20942097-hue/faaff/pull/14)はフィルターCI・CI・CodeQL成功。Dependency ReviewはDependency graph無効のため失敗しています。[設定ページ](https://github.com/r20942097-hue/faaff/settings/security_analysis)で有効化後の再検証が必要です。

他の製品は[製品別の取得・統合条件](PROJECTS.md)、作業順序は[統合実施表](INTEGRATION.md)を参照してください。本体がない録画・AI・Windows操作・Browser Bridgeを推測で実装し直す作業は行っていません。
