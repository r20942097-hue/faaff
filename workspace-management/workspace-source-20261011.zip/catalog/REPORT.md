# 全体整理・統合・改良レポート

2026-10-11。[目的別のツール表](generated/tools.html)、[全ファイル一覧](generated/inventory.html)、[ライブラリ表](generated/libraries.html)、[10製品の現状](PROJECTS.md)から確認できます。

## 今回の成果

10製品の[検索・状態絞り込み付き一覧](generated/projects.html)と[CSV](generated/projects.csv)を追加しました。本体ソースの有無と、履歴・現在のE2Eを分けて確認できます。GitHub参照はローカル原本と照合した固定コミットへ揃えています。[66ファイルの照合記録](results/source-publication-match.json)を参照してください。

| 対象 | 結果 | 確認範囲 |
|---|---|---|
| 共通入口 | 15機能を登録 | 実行・診断・時間制限・結果保存を同じ設定で管理 |
| 一覧・整理 | HTML・CSV・Markdown・JSONを生成 | 検索、分類、原本リンク、SHA256、スマートフォン表示 |
| 管理ツールの復元 | 16ブランチを調査、2固定コミットから73ファイルを選択 | 取得元とハッシュ記録、変更・欠落・未登録コードを検出 |
| Control Plane / Suite | 管理・監査の検証を共通入口へ接続 | v9、Next、プロジェクト監査、根拠確認、Suite監査 |
| Python環境 | 版・配布ハッシュを固定 | 通常検証11依存、Linux実拡張15依存、重複をまとめたライブラリ表41件（3.15用ビルド依存を含む） |
| 文字コード・設定 | UTF-8と改行を明示 | 非UTF-8ロケールでも標準検証通過。子プロセスの出力もUTF-8で統一 |
| 配布 | 圧縮されたソーススナップショット | 固定入力の二重ビルド一致、展開前のハッシュ・パス検査、新規展開後の一覧整合 |
| 広告リスト | 20261011.1、sのmain公開済み | 共通JSON、7配信ファイル、2エンジン1,190通信ケース |
| 日本語表示 | uBO既定設定の問題を修正 | 実拡張で標準・Deepの動作確認。PR #5、CI成功、main未反映 |
| Firefox実拡張 | 12動作項目通過 | 署名付きuBOと固定Docker環境、ローカルfixture。ログイン・実動画再生は対象外 |
| 録画・AI・Windows等の製品 | 本体未取得 | 既存履歴を完成判定へ転用しない。実機テスト未実施 |

## 2つのリポジトリの違い

| 比較 | s | faaff |
|---|---|---|
| 主な役割 | フィルター配信・日本語表示 | 録画資料、候補審査、管理・監査ブランチ |
| 現行広告 | 共通17＋a-ads、uBO拡張 | 共通17の通信ルール |
| 現行追跡 | 9 | 同じ9 |
| 独自機能 | 日本語標準・Deep、v2、Strict | 根拠期限、独立ソース、昇格条件、管理ツール |
| Git履歴・購読URL | 独立、維持 | 独立、維持 |

共通ルールは` s/filter-profiles.json `から生成します。リポジトリ全体は用途と履歴が違うため、それぞれの配信パスを維持し、共通管理を上に置きました。CC0の現行版とGPLのv2は別プロファイルです。

## フォルダの見方

| 場所 | 用途 |
|---|---|
| s/、faaff/ | 原本と独立Git履歴 |
| tools/ | 共通実行・診断・検証・配布 |
| library-files/tool-sources/ | 固定した管理・監査ソースと取得記録 |
| catalog/generated/ | 検索・ツール・ライブラリ・フィルター一覧 |
| catalog/results/ | 今回の検証結果と調査根拠 |
| catalog/artifacts/等 | ローカル環境では原本への分類リンク |
| shared/downloads/ | 保存用。現在登録ファイルなし |
| work/ | 仮想環境、取得キャッシュ、ブラウザー、調査、配布ZIP |

配布ZIPでは分類用symlinkを使わず、一覧から原本を直接開きます。元の2リポジトリを再びコピーして保守するための新しい正本にはしません。保存時点のソーススナップショットです。

## 検証記録

標準17項目と追加4項目が通過しました。回帰テストは標準の262件とSuite監査の26件、計288件通過です。NextのWindows junction 1件はskipとして別に数えます。

- [共通回帰・静的・追加検査](results/latest.json)：各項目の結果とログ
- [Python版照合](results/python-environment.json)
- [取得ツール73ファイルの照合](results/tool-sources.json)
- [Control Plane](results/control-plane.json) / [Suite監査](results/tool-suite-audit.json)
- [実エンジン](results/filter-engine.json)：218ルール、1,190通信、6組込みscriptletケース
- [一覧UI](results/browser.json)：34項目 / [合成DOM](results/filter-browser.json)：12項目
- [現在のFirefox実拡張](results/filter-extension-current.json)：12項目
- [上流145ドメイン・20固定資料](results/upstream-audit.csv)
- [配布パッケージ検証](results/package.json)
- [GitHub更新状況](results/publication.json)

NextのWindows junctionテストは明示的に未実施です。録画資料の過去の「441テスト合格」等は今回の再実行数に含めません。古い取得ソースの検証記録も履歴として区別します。

## 公開と残課題

[s #3](https://github.com/r20942097-hue/s/pull/3)はユーザー承認後にmainへ反映し、主要6購読ファイルを照合しました。[s #5](https://github.com/r20942097-hue/s/pull/5)は日本語表示の追補修正で、CI成功、main未反映です。

[faaff #14](https://github.com/r20942097-hue/faaff/pull/14)はフィルターCI・CI・CodeQL成功。Dependency ReviewはDependency graph無効のため失敗しています。[設定ページ](https://github.com/r20942097-hue/faaff/settings/security_analysis)で有効化後の再検証が必要です。

他の製品は[製品別の取得・統合条件](PROJECTS.md)、作業順序は[統合実施表](INTEGRATION.md)を参照してください。本体がない録画・AI・Windows操作・Browser Bridgeを推測で実装し直す作業は行っていません。

## 2026-10-11の開発追補

共通実行結果は開始時に以前の合格を無効化し、実行中・失敗・実行不可・合格の状態と日時を原子的に保存します。一覧では実行前の準備状況と、doctor実行時に読み込んだ前回の結果・日本時間を別列で表示します。

Windows CIで削除済みソースへのリンク整理を修正しました。Nextの圧縮差は検証アダプターで扱い、元ZIPのハッシュ、展開内容、メタデータ、同一環境での二重ビルド一致は確認します。SuiteではZIP読み込み時に変換される前のパス表記も検査します。取得した73ファイルの元ソースは変更せず、共通入口から明示したアダプターを使います。

[統合ツールのドラフトPR #15](https://github.com/r20942097-hue/faaff/pull/15)へ承認後に公開済みです。最新版の検証記録はpublication.jsonの固定コミットと実行URLを参照してください。Linux/Windowsの管理コード検証は、録画製品の完成判定とは別です。

旧版ソースZIP（71b81cb491dc298a0d4d2c41ff690a7f1b97a8e7ae34b0b0b819ffa9f6644256）は、[固定コミット97cc6a8のCI](https://github.com/r20942097-hue/faaff/actions/runs/38139161227)でLinux/Windows × Python 3.11/3.14の4環境すべて合格しました。これは管理コードの検証です。録画等のWindows製品E2Eは未確認です。

旧版追補：SHA256は87aaeb694bed2e8210abcff7dea95c685173b571314139a882ac0caba156381a。[固定コミット5507652のCI](https://github.com/r20942097-hue/faaff/actions/runs/38139542746)で4環境合格。共通展開で正規化されたZIP名を拒否し、モバイル一覧を改良しました。公開ZIPの実バイトを再取得し、ローカル検証ZIPと同じハッシュであることも確認しました。

## Python 3.15・実行結果の改善

正式版3.15.0で標準17項目、Suite監査、Python版照合、ワークフロー検査、一覧画面を再検証しました。PyYAMLのcp315配布バイナリがないため、固定ソースと固定ビルド依存から標準Python版を導入します。詳細・根拠は[互換性と改善一覧](PYTHON.md)にまとめました。Linux/Windows × Python 3.11/3.14/3.15の6環境CIへ拡張しています。最新ZIPとCIの合否はZIP外のvalidation.jsonで確認してください。

不正なUTF-8を含む子プロセス出力でも終了コードを保持し、診断が落ちないよう修正しました。過去の合格は登録ファイル・実行設定・Python版の一致を確認し、変更時には一覧へ再検証を表示します。取得した73ファイルの原本は保持しています。
