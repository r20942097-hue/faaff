# ツール統合・実行状況

実行前の依存関係診断。ready は動作検証の合格を意味しません。ブラウザー本体・通信・録画E2Eは別途検証が必要です。

診断時のPython：`/workspace/work/pr15-improvement-20261011/verification315/bin/python`（3.15.0）。環境を変更したらdoctorを再実行してください。

前回の結果は診断時に読み込んだ記録です。今回の動作や製品完成を保証しません。

| ツール | 実行前診断 | 前回の実行結果・日時 | 共通コマンド | 不足項目 |
|---|---|---|---|---|
| 成果物・ライブラリ一覧 | 実行準備あり | 未記録<br>—<br> | `python tools/manage.py run --tool catalogue` | なし |
| 広告リスト生成・同期 | 実行準備あり | 未記録<br>—<br> | `python tools/manage.py run --tool filters` | なし |
| 候補の根拠・昇格判定 | 実行準備あり | 未記録<br>—<br> | `python tools/manage.py run --tool candidates` | なし |
| 実エンジン検証 | 要準備 | 未記録<br>—<br> | `python tools/manage.py run --tool engine` | file: work/filter-engine/manifest.json |
| 画面・DOM検証 | 要準備 | 未記録<br>—<br> | `python tools/manage.py run --tool browser` | file: work/filter-engine/manifest.json |
| CI設定検証 | 実行準備あり | 未記録<br>—<br> | `python tools/manage.py run --tool workflows` | なし |
| 監視・録画ツール | 要準備 | 未記録<br>—<br> | ソース復元後に接続 | file: faaff/rplay_watcher/__init__.py<br>implementation: 実行入口が未接続 |
| プロジェクト・配布監査 | 実行準備あり | 未記録<br>—<br> | `python tools/manage.py run --tool governance` | なし |
| Control Planeの抽出・整合性 | 実行準備あり | 未記録<br>—<br> | `python tools/manage.py run --tool control-plane` | なし |
| 依存・検証根拠の確認 | 実行準備あり | 未記録<br>—<br> | `python tools/manage.py run --tool security-intake` | なし |
| Suite配布監査の回帰検証 | 実行準備あり | 未記録<br>—<br> | `python tools/manage.py run --tool suite-audit` | なし |
| Control Plane Nextの配布・復元検証 | 実行準備あり | 未記録<br>—<br> | `python tools/manage.py run --tool control-plane-next` | なし |
| 固定したPython検証環境の照合 | 実行準備あり | 未記録<br>—<br> | `python tools/manage.py run --tool python-environment` | なし |
| Firefox実拡張の動作検証 | 実行準備あり | 未記録<br>—<br> | `python tools/manage.py run --tool firefox-extension` | なし |
| 取得ツール原本の整合性 | 実行準備あり | 未記録<br>—<br> | `python tools/manage.py run --tool source-integrity` | なし |
