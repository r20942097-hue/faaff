# 成果物一覧の見方・統合更新

更新：2026-10-14（日本時間）。[成果物一覧](generated/artifacts.html)は23件です。管理17機能・標準18検査・10製品の取得状況を、配布物の一覧と分けて確認できます。製品本体は9件未取得です。

## 最初に選ぶもの

| 状況 | 選択 | 含まれるもの |
|---|---|---|
| 初回導入 | ツール統合・導入キット20261014.4 | 基準ZIP・24ファイル更新・検証ヘルパー・手順書 |
| 基準ZIPと最新版ヘルパーがある | 管理更新ZIP20261014.4 | 管理コード24ファイル、99,120bytes |
| 過去の版を再現する | 一覧に残した固定版ZIPと検証記録 | 作成時点の内容。現行コードとは区別 |

キットは599,379bytesです。SHA256と固定公開先は成果物一覧から確認してください。基準ZIPは20261012.2を使用します。ファイル名workspace-source-20261011.zipは公開互換名で、実内容の版は一覧の版・ハッシュで確認します。更新ZIP内の一覧・説明は作成時点21件の固定記録です。その時点の導入先として旧版20261014.2の記述も保持します。最新版20261014.4の導入は、同梱KIT-README.mdまたはこの公開ガイドを使います。現在の一覧は新しい更新ZIPとキットを加えた23件です。

## 一覧の見方

1. 名前・用途・版で検索し、公開状況と種類で絞り込みます。登録順・名前順・確認日順・サイズ順で並べ替えられます。「条件を解除」で登録順へ戻ります。
2. main反映済みか、PR公開でmain未反映かを確認します。現在の共通ツール改良はPR #15で公開中です。
3. 公開版の検証範囲・確認日・固定コミットを読みます。本文一致だけの確認を動作合格とは扱いません。
4. 「サイズ・SHA256・原本パス」で同じ版か照合します。生成時の手元確認は一覧作成時点の状態で、閲覧端末の診断ではありません。
5. 前回からの変更は固定した以前の公開ZIP20261012.1との比較です。一覧の再生成で比較対象は移動しません。

| 表示 | 意味 |
|---|---|
| main反映済み | 固定mainコミットの公開本文を確認済み |
| PR公開・main未反映 | PR側の固定版を公開。mainへの反映はまだ |
| 公開版の本文一致 | 固定公開ファイルとSHA256が一致 |
| 検証合格 | 表示した版の、記載した範囲の検証が合格 |
| 内容変更・要再確認 | 手元が公開・検証記録と違う |
| 手元は未照合 | 独立公開一覧など、手元のファイルを診断していない |

HTML・Markdown・CSV・JSONは同じ正本から生成します。CSVはUTF-8です。登録解除の差分は一覧から外れた意味で、原本削除ではありません。

## 導入と更新

初回導入は[KIT-README.md](https://github.com/r20942097-hue/faaff/blob/codex/workspace-management-20261011/workspace-management/KIT-README.md)を参照します。キットZIPと公開チェックサムを照合し、新しいフォルダへ展開して、同梱CLIで新規work/作業先を用意します。既存出力先への上書きは拒否します。途中で失敗した場合は、その処理が作った作業先だけを整理します。

基準ZIPと最新版ヘルパーがある場合は、リポジトリルートで実行します。

```sh
python workspace-management/apply_catalogue_update.py --base workspace-management/workspace-source-20261011.zip --update workspace-management/catalogue-update-20261014.4.zip --update-sha256 ca6f4ecd03dfd1d47e7f4b1aa4311ec7a0fce91b2be6268311d50c6042375589 --output work/integrated-tools-20261014-4
```

展開・適用はパス・CRC・全内容ハッシュ・基準版を照合します。その後、新規作業先で仮想環境を作成してsetup/allを実行します。setupはネットワークを使用します。配布設定はlink_mode=directで、生成後にもカタログ内のシンボリックリンクがないことを検査します。旧版ZIPは固定履歴として保持します。

## 共通ツールから使う

```sh
python tools/manage.py build
python tools/manage.py check
python tools/manage.py doctor
python tools/manage.py run --tool settings-consistency
```

正本catalog/artifacts.jsonと生成処理tools/artifacts.pyを、既存build/all/checkへ接続しています。設定検査は重複、同じcwd・argvの時間制限、直接実行ファイルの登録を確認します。Pythonの-B/-I/-W/-X、Nodeの--no-warnings等、対応する先行フラグの後も照合します。未対応フラグと値不足はエラーです。モジュール・インライン・標準入力・情報表示・Node inspectはexcluded_entriesへ除外形式を記録します。全CLI文法・オプション値の妥当性・全間接依存の検査ではありません。

設定が壊れて共通入口から実行できない場合はpython tools/check_settings.pyを使います。検査前に以前の合格を未完了へ置き換え、失敗を保存します。

## 変更後に確認する範囲

| 変更 | 必要な確認 |
|---|---|
| 一覧の説明・公開先・SHA256 | build/checkと固定公開本文照合 |
| 一覧コード・画面 | test、build/check、browser_smoke.py |
| フィルタールール | filters --checkと該当エンジン検査 |
| 依存・Python・共通管理コード | 新規仮想環境のsetup/allと対象Python・OSのCI |
| 配布ZIP | 全内容ハッシュ、新規先への実CLI適用、適用先のsetup/all |

共通入力3グループは、実行7ファイル／17機能、Python検証7ファイル／4機能、フィルター正本2ファイル／3機能です。doctorは変更入力と再実行コマンドを案内します。未登録の間接依存・外部サービスの状態を推論しません。

## 公開状態の更新候補

```sh
python tools/check_artifact_publication.py --candidate work/artifacts-proposal.json --preview work/artifacts-preview.md
```

新規ファイル名を指定します。固定公開本文のサイズ・SHA256、現在のmainとPR状態を観測し、変更前後を表にします。正本は自動変更しません。不完全な通信・古い正本への観測からは提案を作りません。確認後に公開状態が変わるため、採用前に再観測します。本文の版・ハッシュ・動作検証日は別途レビューが必要です。

[統合・改良案](https://github.com/r20942097-hue/faaff/blob/codex/workspace-management-20261011/workspace-management/TOOL-IMPROVEMENTS.md) · [共有入力](https://github.com/r20942097-hue/faaff/blob/codex/workspace-management-20261011/workspace-management/SHARED-INPUTS.md) · [PR #15](https://github.com/r20942097-hue/faaff/pull/15)

## 本文・版を更新する候補のレビュー（20261014.4）

全体の成果物JSONをwork/へ複製し、更新する版・サイズ・SHA256・固定公開先を編集します。新規・本文・版・種類・原本パスを変更する対象はverification.statusをpendingにします。古いpassedを新SHAへ付け替えた候補は拒否します。

```sh
python tools/check_artifact_publication.py --review work/artifacts-proposed.json --candidate work/artifacts-checked.json --preview work/artifacts-review.md
```

全対象の固定公開本文を新規取得して照合し、変更前後をMarkdown表、確認済み候補を新規JSONへ出力します。正本と入力候補は上書きしません。新規・変更対象はmatched（公開本文一致）として記録し、本文確認では動作合格を付与しません。変更していない動作検証は保持します。確認日は本文一致の確認日です。

正本・候補の変更をネットワーク処理後に再確認し、15分より古い観測・未来の不正時刻・不完全な本文確認は拒否します。基準比較・scope・共有ルールの根拠の変更は、このレビューでは扱いません。共有ルール変更は別の根拠確認が必要です。公開状態だけの候補作成は従来の--candidate/--previewを引き続き使えます。

採用前は正本との差分と必要な動作検証を確認します。確認済み候補は採用操作ではなく、一覧の登録解除も原本削除ではありません。一方の出力後に別の書込みが失敗した場合は全体を失敗とし、残った候補を採用済みとは扱いません。

[実ファイルで確認した比較例（未採用）](https://github.com/r20942097-hue/faaff/blob/codex/workspace-management-20261011/workspace-management/ARTIFACT-REVIEW-EXAMPLE.md)


## 明示登録したテストフォルダ（20261014.4）

取得済みのプロジェクト監査・セキュリティ監査の2ツールへ、directoriesを登録しました。Pythonファイルの本文ハッシュとファイル集合を実行前後で照合し、追加・削除・変更を再検証の対象にします。モジュールのimport先や全ての間接依存は推論しません。

フォルダ内を再帰的に探索し、生成された__pycache__を除外します。シンボリックリンク、隠しディレクトリ、特殊ファイル、空のPythonソース集合、欠落・参照不可は実行前に停止します。1フォルダ4096項目・深さ32、1ツール32フォルダまでです。実行前および各コマンド終了後に入力を再照合し、変更時は後続コマンドを止めて失敗を記録します。検査と読取りをOS上で完全に原子的に固定する仕組みではなく、一時的に変更して元へ戻す全ケースを検知する保証はありません。

doctorは前回合格と現在の追加・削除・変更ファイルを比較し、ツール一覧へ登録フォルダとPythonファイル数を表示します。readyは準備判定で、動作合格とは別です。filesだけの既存登録、共通input_groupsの3グループは維持します。

## 共通テストフォルダと利用先（20261014.5）

input_groupsにもdirectoriesを登録できます。filesだけの既存3グループを維持し、共通管理テストtools/testsのグループを追加しました。利用先はcatalogueとsettings-consistencyの2ツールです。登録先の利用ツールだけがフォルダ集合・本文ハッシュの変更を検知します。

個別登録とグループ登録の重複フォルダは1回だけ列挙し、1ツールの合算でも32フォルダを上限にします。欠落・空集合・symlink・探索上限の異常は、共通グループでも実行を止めます。実行中の変更では後続を停止して終了コード3を記録し、停止理由をコンソールにも表示します。

フォルダ内の対象は拡張子.pyのソースです。生成__pycache__は除外し、全import先や全ての間接依存は推論しません。読取りと実行をOS上で原子的に固定する仕組みではなく、変化して元に戻る全ケースを検知する保証はありません。共通グループ4件・フォルダ照合の利用ツール4件をdoctorで確認できます。
