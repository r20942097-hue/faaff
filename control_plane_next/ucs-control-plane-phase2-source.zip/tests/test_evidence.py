import os
from pathlib import Path
import tempfile
import unittest

from ucs_control_plane.evidence import EvidenceStore
from ucs_control_plane.registry import RegistryStore
from ucs_control_plane.validation import ValidationError, canonical_json_bytes

class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.root=Path(self.td.name)/"state"; self.reg=RegistryStore(self.root); self.ev=EvidenceStore(self.root,self.reg)
    def tearDown(self): self.td.cleanup()
    def test_lifecycle_and_archive_keeps_sealed_metadata(self):
        self.ev.create_draft("e1",canonical_json_bytes({"ok":True}),evidence_type="JSON")
        self.ev.register("e1"); sealed=self.ev.seal("e1"); before=self.ev._meta_path("e1").read_bytes(); idx=self.ev.archive("e1")
        self.assertEqual("SEALED",sealed["lifecycle"]); self.assertEqual(before,self.ev._meta_path("e1").read_bytes()); self.assertEqual("ARCHIVED",idx["state"])
    def test_noncanonical_json_rejected(self):
        with self.assertRaises(ValidationError): self.ev.create_draft("e1",b'{"b":2, "a":1}\n',evidence_type="JSON")
    def test_modified_payload_detected(self):
        self.ev.create_draft("e1",b"abc",evidence_type="BINARY"); self.ev.register("e1")
        self.ev._payload_path("e1").write_bytes(b"abd")
        with self.assertRaises(ValidationError): self.ev.verify_one("e1")
    def test_missing_payload_detected(self):
        self.ev.create_draft("e1",b"abc",evidence_type="BINARY"); self.ev.register("e1"); self.ev._payload_path("e1").unlink()
        with self.assertRaises(ValidationError): self.ev.verify_one("e1")
    def test_hash_mismatch_detected(self):
        self.ev.create_draft("e1",b"abc",evidence_type="BINARY"); meta=self.ev._load_meta("e1"); meta["sha256"]="0"*64
        self.ev._meta_path("e1").write_bytes(canonical_json_bytes(meta))
        with self.assertRaises(ValidationError): self.ev.verify_one("e1")
    def test_seal_after_payload_change_rejected(self):
        self.ev.create_draft("e1",b"abc",evidence_type="BINARY"); self.ev.register("e1"); self.ev._payload_path("e1").write_bytes(b"xyz")
        with self.assertRaises(ValidationError): self.ev.seal("e1")
    def test_sealed_metadata_change_detected(self):
        self.ev.create_draft("e1",b"abc",evidence_type="BINARY"); self.ev.register("e1"); self.ev.seal("e1")
        p=self.ev._meta_path("e1")
        if os.name!="nt": p.chmod(0o600)
        meta=self.ev._load_meta("e1"); meta["sha256"]="0"*64; p.write_bytes(canonical_json_bytes(meta))
        with self.assertRaises(ValidationError): self.ev.verify_one("e1")
    def test_broken_evidence_chain(self):
        self.ev.create_draft("e1",b"abc",evidence_type="BINARY",parent_evidence="missing")
        with self.assertRaisesRegex(ValidationError,"broken evidence chain"): self.ev.register("e1")
    def test_evidence_cycle(self):
        self.ev.create_draft("e1",b"1",evidence_type="BINARY"); self.ev.register("e1")
        self.ev.create_draft("e2",b"2",evidence_type="BINARY",parent_evidence="e1"); self.ev.register("e2")
        # Simulate coordinated external corruption of metadata + registry to ensure cycle detection still fails closed.
        from ucs_control_plane.validation import strict_json_loads
        from ucs_control_plane.io import sha256_bytes
        m1=self.ev._load_meta("e1"); m1["parent_evidence"]="e2"; self.ev._meta_path("e1").write_bytes(canonical_json_bytes(m1))
        state=self.reg.verify(); state["evidence"]["e1"]["parent_evidence"]="e2"; self.reg.path.write_bytes(canonical_json_bytes(state)); self.reg.checksum.write_text(sha256_bytes(self.reg.path.read_bytes())+"  registry.json\n")
        with self.assertRaisesRegex(ValidationError,"evidence cycle"): self.ev.verify_all()
    def test_payload_never_executed(self):
        sentinel=self.root/"EXECUTED"
        payload=f"__import__('pathlib').Path({str(sentinel)!r}).write_text('x')".encode()
        self.ev.create_draft("e1",payload,evidence_type="TEXT"); self.ev.register("e1"); self.ev.seal("e1"); self.ev.verify_one("e1")
        self.assertFalse(sentinel.exists())
    def test_payload_symlink_rejected(self):
        if not hasattr(os,"symlink"): self.skipTest("symlink unsupported")
        self.ev.create_draft("e1",b"abc",evidence_type="BINARY"); self.ev.register("e1")
        p=self.ev._payload_path("e1"); p.unlink(); target=self.root/"target"; target.write_bytes(b"abc")
        try: os.symlink(target,p)
        except OSError: self.skipTest("symlink creation unavailable")
        with self.assertRaises(ValidationError): self.ev.verify_one("e1")
