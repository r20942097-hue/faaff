from pathlib import Path
import shutil
import tempfile
import unittest

from ucs_control_plane.audit import audit
from ucs_control_plane.baseline import initialize_from_file
from ucs_control_plane.registry import RegistryStore
from ucs_control_plane.validation import ValidationError

BASELINE=Path(__file__).resolve().parents[1]/"baseline"/"verified-candidate-baseline.json"

class EventSnapshotAuditTests(unittest.TestCase):
    def setUp(self): self.td=tempfile.TemporaryDirectory(); self.root=Path(self.td.name)/"state"; self.reg=RegistryStore(self.root)
    def tearDown(self): self.td.cleanup()
    def test_event_log_corruption_detected(self):
        self.reg.register_product({"product_id":"p","display_name":"P","current_release_id":None,"classification":"CANDIDATE"})
        p=self.reg.events.path; data=p.read_bytes(); p.write_bytes(data.replace(b'"actor":"operator"',b'"actor":"tampered"',1))
        with self.assertRaises(ValidationError): self.reg.events.verify()
    def test_corrupt_latest_snapshot_falls_back(self):
        self.reg.register_product({"product_id":"p","display_name":"P","current_release_id":None,"classification":"CANDIDATE"})
        self.reg.register_product({"product_id":"q","display_name":"Q","current_release_id":None,"classification":"CANDIDATE"})
        snaps=sorted((self.root/"snapshots").glob("*.json")); self.assertGreaterEqual(len(snaps),2)
        latest=snaps[-1]; latest.write_bytes(b"corrupt")
        chosen=self.reg.snapshots.latest_valid(); self.assertIsNotNone(chosen); self.assertNotEqual(latest,chosen)
    def test_snapshot_verify_detects_corruption(self):
        self.reg.register_product({"product_id":"p","display_name":"P","current_release_id":None,"classification":"CANDIDATE"})
        snap=next((self.root/"snapshots").glob("*.json")); snap.write_bytes(b"{}")
        with self.assertRaises(ValidationError): self.reg.snapshots.verify_all()
    def test_recovery_plan_does_not_restore(self):
        self.reg.register_product({"product_id":"p","display_name":"P","current_release_id":None,"classification":"CANDIDATE"})
        before=self.reg.path.read_bytes(); plan=self.reg.recovery_plan(); self.assertFalse(plan["automatic_restore"]); self.assertEqual(before,self.reg.path.read_bytes())
    def test_baseline_audit_external_artifacts_not_run(self):
        initialize_from_file(self.root,BASELINE); result=audit(self.root)
        self.assertEqual("NOT_RUN",result["checks"]["Artifact"]["status"]); self.assertNotEqual("FAIL",result["overall"])
    def test_local_artifact_hash_mismatch_fails(self):
        state=initialize_from_file(self.root,BASELINE); ad=self.root/"artifacts"; ad.mkdir()
        for r in state["releases"].values(): (ad/r["artifact_filename"]).write_bytes(b"wrong")
        result=audit(self.root); self.assertEqual("FAIL",result["checks"]["Artifact"]["status"])
