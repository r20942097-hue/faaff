import json
import unittest

from ucs_control_plane.validation import (
    ValidationError, canonical_json_bytes, strict_json_loads, validate_no_name_collisions,
    validate_relative_path, validate_rfc3339, validate_semver, semver_compare
)

class ValidationTests(unittest.TestCase):
    def assertRejected(self, value):
        with self.assertRaises(ValidationError): validate_relative_path(value)

    def test_path_traversal(self): self.assertRejected("../x")
    def test_absolute_path(self): self.assertRejected("/tmp/x")
    def test_windows_drive_path(self): self.assertRejected("C:/temp/x")
    def test_unc_path(self): self.assertRejected(r"\\server\share\x")
    def test_null_byte_path(self): self.assertRejected("x\x00y")
    def test_windows_reserved_name(self): self.assertRejected("CON.txt")
    def test_case_collision(self):
        with self.assertRaises(ValidationError): validate_no_name_collisions(["A.zip","a.ZIP"])
    def test_unicode_normalization_collision(self):
        with self.assertRaises(ValidationError): validate_no_name_collisions(["caf\u00e9.zip","cafe\u0301.zip"])
    def test_malformed_json(self):
        with self.assertRaises(ValidationError): strict_json_loads(b"{bad")
    def test_duplicate_json_key(self):
        with self.assertRaises(ValidationError): strict_json_loads(b'{"a":1,"a":2}')
    def test_nan_rejected(self):
        with self.assertRaises(ValidationError): strict_json_loads(b'{"x":NaN}')
    def test_infinity_rejected(self):
        with self.assertRaises(ValidationError): strict_json_loads(b'{"x":Infinity}')
    def test_oversized_metadata(self):
        with self.assertRaises(ValidationError): strict_json_loads(b'"'+b'x'*(70*1024)+b'"')
    def test_deep_json(self):
        raw=("["*40)+"0"+("]"*40)
        with self.assertRaises(ValidationError): strict_json_loads(raw)
    def test_semver_strict_accepts(self): validate_semver("1.2.3-alpha.1+build")
    def test_semver_compare(self):
        self.assertLess(semver_compare("1.2.3-alpha.1","1.2.3"),0)
        self.assertGreater(semver_compare("2.0.0","1.9.9"),0)
    def test_semver_strict_rejects_legacy(self):
        with self.assertRaises(ValidationError): validate_semver("1.51")
    def test_timezone_rfc3339_required(self):
        with self.assertRaises(ValidationError): validate_rfc3339("2026-10-01T12:00:00")
        validate_rfc3339("2026-10-01T12:00:00+09:00")

class PlatformLinkTests(unittest.TestCase):
    @unittest.skipUnless(__import__('os').name == 'nt' and hasattr(__import__('os').path, 'isjunction'), 'real Windows junction creation NOT RUN on this platform')
    def test_windows_junction_detection_placeholder(self):
        # This test is intentionally Windows-only. The runtime guard is implemented via os.path.isjunction.
        self.assertTrue(hasattr(__import__('os').path, 'isjunction'))
