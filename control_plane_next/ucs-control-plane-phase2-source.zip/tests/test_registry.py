import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest import mock

from ucs_control_plane.baseline import initialize_from_file
from ucs_control_plane.registry import RegistryStore
from ucs_control_plane.validation import ValidationError

BASELINE = Path(__file__).resolve().parents[1] / "baseline" / "verified-candidate-baseline.json"

class RegistryTests(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory(); self.root=Path(self.td.name)/"state"
        self.reg=RegistryStore(self.root)
    def tearDown(self): self.td.cleanup()

    def add_release(self):
        rec={"release_id":"p-1_0_0","product_id":"p","version":"1.0.0","semantic_version":"1.0.0","artifact_filename":"p.zip","sha256":"0"*64,"artifact_size":1,"verification_state":"PASS","evidence_references":[],"source_provenance":{"source_type":"TEST","description":"test"},"classification":"CANDIDATE","release_state":"CANDIDATE"}
        self.reg.register_release(rec)
    def test_baseline_initializes_seven_products_and_releases(self):
        state=initialize_from_file(self.root,BASELINE)
        self.assertEqual(7,len(state["products"])); self.assertEqual(7,len(state["releases"]))
        self.assertTrue(all(r["verification_state"]=="PASS" for r in state["releases"].values()))
        self.assertEqual("1.51", next(r["version"] for r in state["releases"].values() if r["product_id"]=="ai-orchestrator"))
        self.assertEqual("1.51.0", next(r["semantic_version"] for r in state["releases"].values() if r["product_id"]=="ai-orchestrator"))
    def test_duplicate_id_rejected(self):
        self.reg.register_product({"product_id":"p","display_name":"P","current_release_id":None,"classification":"CANDIDATE"})
        with self.assertRaises(ValidationError): self.reg.register_product({"product_id":"p","display_name":"P2","current_release_id":None,"classification":"CANDIDATE"})
    def test_unknown_not_promoted(self):
        self.reg.register_product({"product_id":"p","display_name":"P","current_release_id":None,"classification":"CANDIDATE"})
        rec={"release_id":"p-1_0_0","product_id":"p","version":"1.0.0","semantic_version":"1.0.0","artifact_filename":"p.zip","sha256":"0"*64,"artifact_size":1,"verification_state":"UNKNOWN","evidence_references":[],"source_provenance":{"source_type":"TEST","description":"test"},"classification":"CANDIDATE","release_state":"CANDIDATE"}
        self.reg.register_release(rec)
        with self.assertRaises(ValidationError): self.reg.promote_release("p-1_0_0")
    def test_interrupted_write_keeps_old_registry(self):
        self.reg.register_product({"product_id":"p","display_name":"P","current_release_id":None,"classification":"CANDIDATE"})
        before=self.reg.path.read_bytes()
        import ucs_control_plane.registry as mod
        original=mod.atomic_write_bytes
        def fail_on_registry(path,payload,*a,**k):
            if Path(path)==self.reg.path: raise OSError("simulated interruption")
            return original(path,payload,*a,**k)
        with mock.patch.object(mod,"atomic_write_bytes",side_effect=fail_on_registry):
            with self.assertRaises(OSError):
                self.reg.register_product({"product_id":"q","display_name":"Q","current_release_id":None,"classification":"CANDIDATE"})
        self.assertEqual(before,self.reg.path.read_bytes()); self.reg.verify()
    def test_concurrent_write_serializes(self):
        self.reg.register_product({"product_id":"p","display_name":"P","current_release_id":None,"classification":"CANDIDATE"})
        self.add_release()
        errs=[]
        def worker(cid):
            try:
                self.reg.register_capability({"capability_id":cid,"owning_product":"p","required_evidence":[],"minimum_version":"1.0.0","compatibility_constraints":["offline"],"risk_level":"LOW","required_release_state":"CANDIDATE"})
            except Exception as e: errs.append(e)
        ts=[threading.Thread(target=worker,args=(f"c{i}",)) for i in range(4)]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertFalse(errs); self.assertEqual(4,len(self.reg.verify()["capabilities"]))
    def test_capability_contract_validated(self):
        self.reg.register_product({"product_id":"p","display_name":"P","current_release_id":None,"classification":"CANDIDATE"})
        self.add_release()
        self.reg.register_capability({"capability_id":"read-status","owning_product":"p","required_evidence":[],"minimum_version":"1.0.0","compatibility_constraints":["no-cross-product-db-mutation"],"risk_level":"LOW","required_release_state":"CANDIDATE"})
        self.assertIn("read-status",self.reg.verify()["capabilities"])
