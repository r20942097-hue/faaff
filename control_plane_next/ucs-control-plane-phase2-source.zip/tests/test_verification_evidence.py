import hashlib
import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = Path("evidence/phase2-local-verification.json")


class VerificationEvidenceTests(unittest.TestCase):
    def test_file_inventory_is_complete_and_never_self_references(self):
        payload = json.loads((ROOT / EVIDENCE).read_text(encoding="utf-8"))
        entries = payload["files"]
        paths = [entry["path"] for entry in entries]
        self.assertEqual(len(paths), len(set(paths)))
        self.assertNotIn(EVIDENCE.as_posix(), paths)
        expected = {"README.md", "pyproject.toml", "baseline/verified-candidate-baseline.json"}
        expected.update(path.relative_to(ROOT).as_posix() for path in (ROOT / "tests").glob("*.py"))
        expected.update(path.relative_to(ROOT).as_posix() for path in (ROOT / "ucs_control_plane").glob("*.py"))
        self.assertEqual(expected, set(paths))
        for entry in entries:
            content = (ROOT / entry["path"]).read_bytes()
            self.assertEqual(entry["size"], len(content), entry["path"])
            self.assertEqual(entry["sha256"], hashlib.sha256(content).hexdigest(), entry["path"])
