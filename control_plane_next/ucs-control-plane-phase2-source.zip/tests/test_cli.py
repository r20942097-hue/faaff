import io
from contextlib import redirect_stdout, redirect_stderr
from pathlib import Path
import tempfile
import unittest

from ucs_control_plane.cli import main

BASELINE=Path(__file__).resolve().parents[1]/"baseline"/"verified-candidate-baseline.json"

class CliTests(unittest.TestCase):
    def test_required_verify_commands(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)/"state"
            self.assertEqual(0,main(["baseline","init",str(BASELINE),"--root",str(root)]))
            self.assertEqual(0,main(["registry","verify","--root",str(root)]))
            self.assertEqual(0,main(["evidence","verify","--root",str(root)]))
            self.assertEqual(0,main(["snapshot","verify","--root",str(root)]))
            self.assertEqual(0,main(["audit","--json","--root",str(root)]))
