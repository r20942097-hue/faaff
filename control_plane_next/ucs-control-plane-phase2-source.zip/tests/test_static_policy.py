import ast
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]/"ucs_control_plane"

class StaticPolicyTests(unittest.TestCase):
    def test_no_network_client_imports(self):
        forbidden={"socket","urllib","http.client","requests","httpx","aiohttp","ftplib"}
        found=[]
        for path in ROOT.glob("*.py"):
            tree=ast.parse(path.read_text("utf-8"),filename=str(path))
            for node in ast.walk(tree):
                if isinstance(node,ast.Import):
                    for alias in node.names:
                        if alias.name in forbidden or any(alias.name.startswith(x+".") for x in forbidden): found.append((path.name,alias.name))
                elif isinstance(node,ast.ImportFrom) and node.module:
                    if node.module in forbidden or any(node.module.startswith(x+".") for x in forbidden): found.append((path.name,node.module))
        self.assertEqual([],found)
    def test_no_payload_execution_primitives_in_evidence_module(self):
        tree=ast.parse((ROOT/"evidence.py").read_text("utf-8"))
        calls={n.func.id for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)}
        self.assertTrue({"eval","exec","compile"}.isdisjoint(calls))
