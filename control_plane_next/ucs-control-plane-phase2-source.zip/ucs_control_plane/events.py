from __future__ import annotations

import hashlib
import uuid
from pathlib import Path

from .io import append_fsync
from .validation import canonical_json_bytes, now_rfc3339, strict_json_loads, validate_rfc3339, ValidationError

EVENT_TYPES = {
    "PRODUCT_REGISTERED", "RELEASE_REGISTERED", "EVIDENCE_REGISTERED", "EVIDENCE_SEALED",
    "EVIDENCE_ARCHIVED", "CAPABILITY_REGISTERED", "RELEASE_PROMOTED", "RELEASE_REJECTED",
    "SNAPSHOT_CREATED", "RECOVERY_PLANNED"
}

class EventLog:
    def __init__(self, root: Path):
        self.path = root / "events" / "events.jsonl"

    @staticmethod
    def _hash_record(record: dict) -> str:
        data = dict(record); data.pop("event_hash", None)
        return hashlib.sha256(canonical_json_bytes(data)).hexdigest()

    def verify(self) -> list[dict]:
        if not self.path.exists():
            return []
        if self.path.is_symlink() or not self.path.is_file():
            raise ValidationError("event log replaced by non-regular file")
        if self.path.stat().st_size > 32 * 1024 * 1024:
            raise ValidationError("event log exceeds bound")
        events=[]; previous=None
        with self.path.open("rb") as f:
            for index, raw in enumerate(f, 1):
                if len(raw) > 128 * 1024:
                    raise ValidationError("event line exceeds bound")
                rec = strict_json_loads(raw, max_bytes=128*1024)
                if not isinstance(rec, dict) or rec.get("event_type") not in EVENT_TYPES:
                    raise ValidationError(f"invalid event at line {index}")
                try: uuid.UUID(rec["event_id"])
                except Exception as exc: raise ValidationError("invalid event_id") from exc
                validate_rfc3339(rec.get("timestamp"))
                if rec.get("previous_event_hash") != previous:
                    raise ValidationError("event chain broken")
                actual=self._hash_record(rec)
                if rec.get("event_hash") != actual:
                    raise ValidationError("event hash mismatch")
                previous=actual; events.append(rec)
        return events

    def append(self, *, event_type: str, actor: str, reason: str, previous_state=None, new_state=None,
               product_id=None, release_id=None, evidence_id=None) -> dict:
        if event_type not in EVENT_TYPES: raise ValidationError("unsupported event type")
        if not isinstance(actor, str) or not actor or len(actor) > 128: raise ValidationError("invalid actor")
        if not isinstance(reason, str) or not reason or len(reason.encode()) > 4096: raise ValidationError("invalid reason")
        prior=self.verify(); prev=prior[-1]["event_hash"] if prior else None
        rec={
            "event_id": str(uuid.uuid4()), "timestamp": now_rfc3339(), "event_type": event_type,
            "actor": actor, "previous_state": previous_state, "new_state": new_state,
            "product_id": product_id, "release_id": release_id, "evidence_id": evidence_id,
            "reason": reason, "previous_event_hash": prev,
        }
        rec["event_hash"]=self._hash_record(rec)
        append_fsync(self.path, canonical_json_bytes(rec))
        return rec
