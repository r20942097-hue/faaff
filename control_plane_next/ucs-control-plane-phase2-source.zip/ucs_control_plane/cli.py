from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .audit import audit
from .baseline import initialize_from_file
from .evidence import EvidenceStore
from .registry import RegistryStore


def _emit(obj,as_json=True):
    if as_json: print(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True))
    else:
        if "checks" in obj:
            print(f"overall: {obj['overall']}")
            for name,res in obj["checks"].items(): print(f"{name}: {res['status']} - {res['detail']}")
        else: print(obj)

def main(argv=None)->int:
    p=argparse.ArgumentParser(prog="ucs"); sub=p.add_subparsers(dest="command",required=True)
    a=sub.add_parser("audit"); a.add_argument("--json",action="store_true"); a.add_argument("--root",default=".ucs-control-plane")
    r=sub.add_parser("registry"); rs=r.add_subparsers(dest="action",required=True); rv=rs.add_parser("verify"); rv.add_argument("--root",default=".ucs-control-plane")
    e=sub.add_parser("evidence"); es=e.add_subparsers(dest="action",required=True); ev=es.add_parser("verify"); ev.add_argument("--root",default=".ucs-control-plane")
    s=sub.add_parser("snapshot"); ss=s.add_subparsers(dest="action",required=True); sv=ss.add_parser("verify"); sv.add_argument("--root",default=".ucs-control-plane")
    rec=sub.add_parser("recovery"); recs=rec.add_subparsers(dest="action",required=True); rp=recs.add_parser("plan"); rp.add_argument("--root",default=".ucs-control-plane")
    b=sub.add_parser("baseline"); bs=b.add_subparsers(dest="action",required=True); bi=bs.add_parser("init"); bi.add_argument("baseline_file"); bi.add_argument("--root",default=".ucs-control-plane")
    ns=p.parse_args(argv)
    try:
        root=Path(ns.root)
        if ns.command=="audit":
            result=audit(root); _emit(result,ns.json); return 1 if result["overall"]=="FAIL" else 0
        if ns.command=="registry": _emit({"status":"PASS","revision":RegistryStore(root).verify()["revision"]}); return 0
        if ns.command=="evidence": _emit({"status":"PASS","evidence":EvidenceStore(root).verify_all()}); return 0
        if ns.command=="snapshot": _emit({"status":"PASS","snapshots":[str(x) for x in RegistryStore(root).snapshots.verify_all()]}); return 0
        if ns.command=="recovery": _emit(RegistryStore(root).recovery_plan()); return 0
        if ns.command=="baseline": _emit(initialize_from_file(root,Path(ns.baseline_file))); return 0
    except Exception as exc:
        print(json.dumps({"status":"FAIL","error":str(exc)},ensure_ascii=False),file=sys.stderr); return 2
    return 2

if __name__=="__main__": raise SystemExit(main())
