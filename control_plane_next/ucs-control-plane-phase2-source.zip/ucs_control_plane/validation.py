from __future__ import annotations

import datetime as dt
import json
import math
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import unicodedata
from typing import Any

SAFE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,127}$")
SEMVER_RE = re.compile(
    r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)"
    r"(?:-((?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*))?"
    r"(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$"
)
RFC3339_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$")
WINDOWS_RESERVED = {
    "con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))
}
MAX_METADATA_BYTES = 64 * 1024
MAX_JSON_DEPTH = 32
MAX_JSON_NODES = 10000
MAX_STRING = 32 * 1024

class ValidationError(ValueError):
    pass


def now_rfc3339() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def validate_rfc3339(value: str) -> None:
    if not isinstance(value, str) or not RFC3339_RE.fullmatch(value):
        raise ValidationError("timestamp must be timezone-qualified RFC3339")
    parsed = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValidationError("timestamp must include timezone")


def validate_semver(value: str) -> None:
    if not isinstance(value, str) or not SEMVER_RE.fullmatch(value):
        raise ValidationError(f"invalid strict SemVer: {value!r}")




def semver_compare(a: str, b: str) -> int:
    """Compare strict SemVer values without accepting legacy labels."""
    validate_semver(a); validate_semver(b)
    ma = SEMVER_RE.fullmatch(a); mb = SEMVER_RE.fullmatch(b)
    ca = tuple(int(ma.group(i)) for i in (1, 2, 3)); cb = tuple(int(mb.group(i)) for i in (1, 2, 3))
    if ca != cb: return -1 if ca < cb else 1
    pa, pb = ma.group(4), mb.group(4)
    if pa is None and pb is None: return 0
    if pa is None: return 1
    if pb is None: return -1
    aa, bb = pa.split('.'), pb.split('.')
    for x, y in zip(aa, bb):
        if x == y: continue
        xn, yn = x.isdigit(), y.isdigit()
        if xn and yn: return -1 if int(x) < int(y) else 1
        if xn != yn: return -1 if xn else 1
        return -1 if x < y else 1
    return (len(aa) > len(bb)) - (len(aa) < len(bb))

def validate_safe_id(value: str, label: str = "id") -> None:
    if not isinstance(value, str) or not SAFE_ID_RE.fullmatch(value):
        raise ValidationError(f"unsafe {label}")
    if value.casefold() in WINDOWS_RESERVED:
        raise ValidationError(f"reserved {label}")


def _validate_component(name: str) -> None:
    if not name or name in {".", ".."} or "\x00" in name:
        raise ValidationError("unsafe path component")
    if name.endswith((" ", ".")):
        raise ValidationError("Windows-unsafe trailing character")
    stem = name.split(".", 1)[0].casefold()
    if stem in WINDOWS_RESERVED:
        raise ValidationError("Windows reserved name")


def validate_relative_path(value: str, *, single_component: bool = False) -> None:
    if not isinstance(value, str) or not value or "\x00" in value:
        raise ValidationError("invalid path")
    if value.startswith(("/", "\\")) or value.startswith("//") or value.startswith("\\\\"):
        raise ValidationError("absolute/UNC path rejected")
    win = PureWindowsPath(value)
    if win.drive or win.root:
        raise ValidationError("Windows drive/absolute path rejected")
    if "\\" in value:
        raise ValidationError("backslash path rejected")
    posix = PurePosixPath(value)
    if posix.is_absolute() or any(p in {"", ".", ".."} for p in posix.parts):
        raise ValidationError("path traversal rejected")
    if single_component and len(posix.parts) != 1:
        raise ValidationError("filename must be one component")
    for part in posix.parts:
        _validate_component(part)


def collision_key(value: str) -> str:
    return unicodedata.normalize("NFKC", value).casefold()


def validate_no_name_collisions(values: list[str]) -> None:
    seen: set[str] = set()
    for value in values:
        validate_relative_path(value)
        key = collision_key(value)
        if key in seen:
            raise ValidationError("case/Unicode normalization collision")
        seen.add(key)


def _pairs(items):
    out = {}
    for k, v in items:
        if k in out:
            raise ValidationError(f"duplicate JSON key: {k}")
        out[k] = v
    return out


def _reject_constant(value: str):
    raise ValidationError(f"non-finite JSON number rejected: {value}")


def _walk_limits(value: Any, depth: int = 0, counter: list[int] | None = None) -> None:
    if counter is None:
        counter = [0]
    counter[0] += 1
    if counter[0] > MAX_JSON_NODES or depth > MAX_JSON_DEPTH:
        raise ValidationError("JSON structural limit exceeded")
    if isinstance(value, str) and len(value.encode("utf-8")) > MAX_STRING:
        raise ValidationError("JSON string too large")
    if isinstance(value, float) and not math.isfinite(value):
        raise ValidationError("non-finite number rejected")
    if isinstance(value, dict):
        for k, v in value.items():
            if not isinstance(k, str):
                raise ValidationError("JSON object key must be string")
            _walk_limits(v, depth + 1, counter)
    elif isinstance(value, list):
        for v in value:
            _walk_limits(v, depth + 1, counter)


def strict_json_loads(data: bytes | str, *, max_bytes: int = MAX_METADATA_BYTES):
    raw = data.encode("utf-8") if isinstance(data, str) else data
    if len(raw) > max_bytes:
        raise ValidationError("JSON exceeds byte limit")
    if b"\x00" in raw:
        raise ValidationError("NUL byte rejected")
    try:
        text = raw.decode("utf-8")
        obj = json.loads(text, object_pairs_hook=_pairs, parse_constant=_reject_constant)
    except UnicodeDecodeError as exc:
        raise ValidationError("JSON must be UTF-8") from exc
    except json.JSONDecodeError as exc:
        raise ValidationError("malformed JSON") from exc
    _walk_limits(obj)
    return obj


def canonical_json_bytes(value: Any) -> bytes:
    _walk_limits(value)
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def ensure_canonical_json_payload(payload: bytes) -> Any:
    obj = strict_json_loads(payload, max_bytes=4 * 1024 * 1024)
    if payload != canonical_json_bytes(obj):
        raise ValidationError("JSON evidence payload is not canonical")
    return obj


def path_is_link_or_junction(path: Path) -> bool:
    if path.is_symlink():
        return True
    isjunction = getattr(os.path, "isjunction", None)
    return bool(isjunction and isjunction(path))


def ensure_regular_file_no_links(path: Path, root: Path) -> None:
    root = root.resolve()
    try:
        rel = path.resolve(strict=False).relative_to(root)
    except ValueError as exc:
        raise ValidationError("path escaped storage root") from exc
    current = root
    for part in rel.parts:
        current = current / part
        if current.exists() and path_is_link_or_junction(current):
            raise ValidationError("symlink/junction rejected")
    if not path.exists() or not path.is_file() or path_is_link_or_junction(path):
        raise ValidationError("required regular file missing or replaced")
