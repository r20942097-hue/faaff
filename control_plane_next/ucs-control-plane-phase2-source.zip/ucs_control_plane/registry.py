from __future__ import annotations

import copy
from pathlib import Path
from typing import Callable

from .events import EventLog
from .io import atomic_write_bytes, exclusive_lock, sha256_bytes
from .validation import (
    ValidationError, canonical_json_bytes, strict_json_loads, validate_no_name_collisions,
    validate_relative_path, validate_safe_id, validate_semver, semver_compare, now_rfc3339
)

VERIFY_STATES={"PASS","FAIL","NOT_RUN","UNKNOWN"}
CLASSIFICATIONS={"CANDIDATE","FORMAL","HISTORICAL"}
RELEASE_STATES={"CANDIDATE","FORMAL","HISTORICAL","REJECTED"}
EVIDENCE_STATES={"DRAFT","REGISTERED","SEALED","ARCHIVED"}
RISK_LEVELS={"LOW","MEDIUM","HIGH","CRITICAL"}


def empty_state() -> dict:
    return {"schema_version":"1.0.0","revision":0,"updated_at":now_rfc3339(),"products":{},"releases":{},"evidence":{},"capabilities":{}}


def _nonempty_str(value, label, max_len=2048):
    if not isinstance(value,str) or not value or len(value.encode())>max_len: raise ValidationError(f"invalid {label}")


def validate_release(rec: dict) -> None:
    required={"release_id","product_id","version","semantic_version","artifact_filename","sha256","artifact_size","verification_state","evidence_references","source_provenance","classification","release_state"}
    if set(rec)!=required: raise ValidationError("release fields mismatch")
    validate_safe_id(rec["release_id"],"release_id"); validate_safe_id(rec["product_id"],"product_id")
    _nonempty_str(rec["version"],"version",128); validate_semver(rec["semantic_version"])
    validate_relative_path(rec["artifact_filename"],single_component=True)
    if not isinstance(rec["sha256"],str) or len(rec["sha256"])!=64 or any(c not in "0123456789abcdef" for c in rec["sha256"]): raise ValidationError("invalid sha256")
    if type(rec["artifact_size"]) is not int or rec["artifact_size"] < 0: raise ValidationError("invalid artifact_size")
    if rec["verification_state"] not in VERIFY_STATES: raise ValidationError("invalid verification state")
    if rec["classification"] not in CLASSIFICATIONS or rec["release_state"] not in RELEASE_STATES: raise ValidationError("invalid release classification/state")
    refs=rec["evidence_references"]
    if not isinstance(refs,list) or any(not isinstance(x,str) or not x or len(x)>512 for x in refs) or len(set(refs))!=len(refs): raise ValidationError("invalid evidence references")
    prov=rec["source_provenance"]
    if not isinstance(prov,dict) or set(prov)!={"source_type","description"}: raise ValidationError("invalid provenance")
    _nonempty_str(prov["source_type"],"source_type",64); _nonempty_str(prov["description"],"provenance description",4096)


def validate_state(state: dict) -> None:
    if not isinstance(state,dict) or set(state)!={"schema_version","revision","updated_at","products","releases","evidence","capabilities"}: raise ValidationError("registry state fields mismatch")
    validate_semver(state["schema_version"])
    if type(state["revision"]) is not int or state["revision"]<0: raise ValidationError("invalid revision")
    from .validation import validate_rfc3339
    validate_rfc3339(state["updated_at"])
    for key in ("products","releases","evidence","capabilities"):
        if not isinstance(state[key],dict): raise ValidationError(f"{key} must be object")
    for pid,rec in state["products"].items():
        validate_safe_id(pid,"product_id")
        if not isinstance(rec,dict) or set(rec)!={"product_id","display_name","current_release_id","classification"}: raise ValidationError("product fields mismatch")
        if rec["product_id"]!=pid: raise ValidationError("product key mismatch")
        _nonempty_str(rec["display_name"],"display_name",256)
        if rec["current_release_id"] is not None: validate_safe_id(rec["current_release_id"],"release_id")
        if rec["classification"] not in CLASSIFICATIONS: raise ValidationError("invalid product classification")
    artifact_names=[]
    for rid,rec in state["releases"].items():
        validate_release(rec)
        if rec["release_id"]!=rid or rec["product_id"] not in state["products"]: raise ValidationError("release linkage invalid")
        artifact_names.append(rec["artifact_filename"])
    validate_no_name_collisions(artifact_names)
    for pid,prod in state["products"].items():
        rid=prod["current_release_id"]
        if rid is not None and (rid not in state["releases"] or state["releases"][rid]["product_id"]!=pid): raise ValidationError("current release invalid")
    for eid,rec in state["evidence"].items():
        validate_safe_id(eid,"evidence_id")
        if not isinstance(rec,dict) or set(rec)!={"evidence_id","state","sha256","payload_size","evidence_type","parent_evidence","supersedes"}: raise ValidationError("evidence index fields mismatch")
        if rec["evidence_id"]!=eid or rec["state"] not in EVIDENCE_STATES: raise ValidationError("invalid evidence state")
        if not isinstance(rec["sha256"],str) or len(rec["sha256"])!=64: raise ValidationError("invalid evidence sha")
        if type(rec["payload_size"]) is not int or rec["payload_size"]<0: raise ValidationError("invalid payload size")
        if rec["evidence_type"] not in {"JSON","TEXT","BINARY"}: raise ValidationError("invalid evidence type")
        for link in ("parent_evidence","supersedes"):
            if rec[link] is not None: validate_safe_id(rec[link],link)
    for cid,rec in state["capabilities"].items():
        validate_safe_id(cid,"capability_id")
        expected={"capability_id","owning_product","required_evidence","minimum_version","compatibility_constraints","risk_level","required_release_state"}
        if not isinstance(rec,dict) or set(rec)!=expected or rec["capability_id"]!=cid: raise ValidationError("capability fields mismatch")
        if rec["owning_product"] not in state["products"]: raise ValidationError("capability owner missing")
        if not isinstance(rec["required_evidence"],list) or any(not isinstance(x,str) for x in rec["required_evidence"]): raise ValidationError("required_evidence invalid")
        for e in rec["required_evidence"]: validate_safe_id(e,"evidence_id")
        validate_semver(rec["minimum_version"])
        if not isinstance(rec["compatibility_constraints"],list) or any(not isinstance(x,str) or not x for x in rec["compatibility_constraints"]): raise ValidationError("compatibility constraints invalid")
        if rec["risk_level"] not in RISK_LEVELS or rec["required_release_state"] not in RELEASE_STATES-{"REJECTED"}: raise ValidationError("capability risk/state invalid")
        for eid in rec["required_evidence"]:
            if eid not in state["evidence"] or state["evidence"][eid]["state"] not in {"SEALED","ARCHIVED"}:
                raise ValidationError("capability required evidence must exist and be sealed")
        current_id=state["products"][rec["owning_product"]]["current_release_id"]
        if current_id is None or current_id not in state["releases"]: raise ValidationError("capability owner has no current release")
        current=state["releases"][current_id]
        if semver_compare(current["semantic_version"],rec["minimum_version"]) < 0: raise ValidationError("capability minimum version not met")
        rank={"HISTORICAL":0,"CANDIDATE":1,"FORMAL":2}
        if current["release_state"]=="REJECTED" or rank.get(current["release_state"],-1) < rank[rec["required_release_state"]]: raise ValidationError("capability required release state not met")


class SnapshotManager:
    def __init__(self, root: Path): self.dir=root/"snapshots"
    def create(self, payload: bytes, revision: int) -> Path:
        self.dir.mkdir(parents=True,exist_ok=True)
        stamp=now_rfc3339().replace(":","").replace("-","").replace(".","")
        path=self.dir/f"{stamp}-r{revision}.json"; checksum=sha256_bytes(payload)
        atomic_write_bytes(path,payload); atomic_write_bytes(path.with_suffix(".sha256"),(checksum+"  "+path.name+"\n").encode())
        return path
    def verify_one(self,path:Path)->dict:
        if path.is_symlink() or not path.is_file(): raise ValidationError("snapshot missing/replaced")
        side=path.with_suffix(".sha256")
        if side.is_symlink() or not side.is_file(): raise ValidationError("snapshot checksum missing")
        payload=path.read_bytes(); expected=side.read_text("utf-8").split()[0]
        if sha256_bytes(payload)!=expected: raise ValidationError("snapshot checksum mismatch")
        state=strict_json_loads(payload,max_bytes=4*1024*1024); validate_state(state); return state
    def verify_all(self)->list[Path]:
        if not self.dir.exists(): return []
        valid=[]
        for p in sorted(self.dir.glob("*.json")):
            self.verify_one(p); valid.append(p)
        return valid
    def latest_valid(self)->Path|None:
        if not self.dir.exists(): return None
        for p in sorted(self.dir.glob("*.json"),reverse=True):
            try: self.verify_one(p); return p
            except ValidationError: continue
        return None


class RegistryStore:
    def __init__(self, root: Path):
        self.root=Path(root); self.path=self.root/"registry"/"registry.json"; self.checksum=self.root/"registry"/"registry.sha256"; self.lock=self.root/".write.lock"
        self.events=EventLog(self.root); self.snapshots=SnapshotManager(self.root)
    def load(self)->dict:
        if not self.path.exists(): return empty_state()
        if self.path.is_symlink() or not self.path.is_file(): raise ValidationError("registry replaced")
        payload=self.path.read_bytes(); state=strict_json_loads(payload,max_bytes=4*1024*1024); validate_state(state); return state
    def verify(self)->dict:
        state=self.load()
        if self.path.exists():
            if not self.checksum.exists() or self.checksum.is_symlink(): raise ValidationError("registry checksum missing")
            expected=self.checksum.read_text("utf-8").split()[0]
            if sha256_bytes(self.path.read_bytes())!=expected: raise ValidationError("registry checksum mismatch")
        return state
    def _write_state(self,state:dict)->None:
        validate_state(state); payload=canonical_json_bytes(state); atomic_write_bytes(self.path,payload)
        actual=sha256_bytes(self.path.read_bytes()); atomic_write_bytes(self.checksum,(actual+"  registry.json\n").encode())
        if actual!=sha256_bytes(payload): raise ValidationError("post-write checksum mismatch")
    def update(self, mutator: Callable[[dict],None], *, event_type:str, actor:str, reason:str, previous_state=None, new_state=None, product_id=None, release_id=None, evidence_id=None)->dict:
        with exclusive_lock(self.lock):
            current=self.verify(); old_payload=canonical_json_bytes(current); snap=self.snapshots.create(old_payload,current["revision"])
            updated=copy.deepcopy(current); mutator(updated); updated["revision"]=current["revision"]+1; updated["updated_at"]=now_rfc3339(); validate_state(updated)
            self._write_state(updated)
            self.events.append(event_type="SNAPSHOT_CREATED",actor=actor,reason=f"pre-update snapshot {snap.name}",previous_state=current["revision"],new_state=current["revision"],product_id=product_id,release_id=release_id,evidence_id=evidence_id)
            self.events.append(event_type=event_type,actor=actor,reason=reason,previous_state=previous_state,new_state=new_state,product_id=product_id,release_id=release_id,evidence_id=evidence_id)
            return updated
    def register_product(self, rec:dict, *, actor="operator"):
        pid=rec.get("product_id"); validate_safe_id(pid,"product_id")
        def mut(s):
            if pid in s["products"]: raise ValidationError("duplicate product ID")
            s["products"][pid]=rec
        return self.update(mut,event_type="PRODUCT_REGISTERED",actor=actor,reason="register product",new_state=rec.get("classification"),product_id=pid)
    def register_release(self, rec:dict, *, actor="operator"):
        validate_release(rec); rid=rec["release_id"]; pid=rec["product_id"]
        def mut(s):
            if rid in s["releases"]: raise ValidationError("duplicate release ID")
            if pid not in s["products"]: raise ValidationError("unknown product")
            s["releases"][rid]=rec; s["products"][pid]["current_release_id"]=rid
        return self.update(mut,event_type="RELEASE_REGISTERED",actor=actor,reason="register release",new_state=rec["release_state"],product_id=pid,release_id=rid)
    def register_capability(self, rec:dict, *, actor="operator"):
        cid=rec.get("capability_id"); validate_safe_id(cid,"capability_id")
        def mut(s):
            if cid in s["capabilities"]: raise ValidationError("duplicate capability ID")
            s["capabilities"][cid]=rec
        return self.update(mut,event_type="CAPABILITY_REGISTERED",actor=actor,reason="register capability",new_state=rec.get("required_release_state"),product_id=rec.get("owning_product"))
    def upsert_evidence_index(self, rec:dict, *, event_type:str, actor:str, previous_state=None, new_state=None):
        eid=rec["evidence_id"]
        def mut(s):
            if event_type=="EVIDENCE_REGISTERED" and eid in s["evidence"]: raise ValidationError("duplicate evidence ID")
            s["evidence"][eid]=rec
        return self.update(mut,event_type=event_type,actor=actor,reason=event_type.lower().replace("_"," "),previous_state=previous_state,new_state=new_state,evidence_id=eid)
    def promote_release(self,rid:str,*,actor="operator",reason="explicit promotion"):
        def mut(s):
            if rid not in s["releases"]: raise ValidationError("unknown release")
            r=s["releases"][rid]
            if r["verification_state"]!="PASS": raise ValidationError("only PASS release can be promoted")
            if r["release_state"]!="CANDIDATE": raise ValidationError("only candidate can be promoted")
            r["release_state"]="FORMAL"; r["classification"]="FORMAL"; s["products"][r["product_id"]]["classification"]="FORMAL"
        state=self.load(); old=state["releases"].get(rid,{}).get("release_state")
        return self.update(mut,event_type="RELEASE_PROMOTED",actor=actor,reason=reason,previous_state=old,new_state="FORMAL",release_id=rid,product_id=state["releases"].get(rid,{}).get("product_id"))
    def reject_release(self,rid:str,*,actor="operator",reason="explicit rejection"):
        state=self.load(); old=state["releases"].get(rid,{}).get("release_state")
        def mut(s):
            if rid not in s["releases"]: raise ValidationError("unknown release")
            s["releases"][rid]["release_state"]="REJECTED"
        return self.update(mut,event_type="RELEASE_REJECTED",actor=actor,reason=reason,previous_state=old,new_state="REJECTED",release_id=rid,product_id=state["releases"].get(rid,{}).get("product_id"))
    def recovery_plan(self,*,actor="operator") -> dict:
        latest=self.snapshots.latest_valid(); state=self.verify()
        plan={"automatic_restore":False,"current_revision":state["revision"],"latest_valid_snapshot":str(latest) if latest else None,"action":"manual_review_required"}
        with exclusive_lock(self.lock):
            self.events.append(event_type="RECOVERY_PLANNED",actor=actor,reason="generated recovery plan only; no restore",previous_state=state["revision"],new_state=state["revision"])
        return plan
