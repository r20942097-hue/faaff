from __future__ import annotations

import json
from pathlib import Path

from .registry import RegistryStore
from .validation import ValidationError

NORMALIZED={"0.30":"0.30.0","6.49.12":"6.49.12","0.1.8":"0.1.8","1.51":"1.51.0","0.10":"0.10.0","0.3.0":"0.3.0","0.1.0":"0.1.0"}
PRODUCT_IDS={
    "Universal Control Suite":"universal-control-suite", "Universal Live Watcher":"universal-live-watcher",
    "Windows Control":"windows-control", "AI Orchestrator":"ai-orchestrator", "Shared Foundation":"suite-foundation",
    "Browser Control":"browser-control", "Media / Download Tools":"media-download-tools"
}

def initialize_from_file(root:Path, baseline_path:Path, *, actor="baseline-import"):
    data=json.loads(Path(baseline_path).read_text("utf-8")); products=data.get("products")
    if not isinstance(products,list) or len(products)!=7: raise ValidationError("baseline must contain seven products")
    reg=RegistryStore(root)
    if reg.path.exists(): raise ValidationError("registry already initialized")
    for item in products:
        name=item["display_name"]; pid=PRODUCT_IDS.get(name)
        if not pid: raise ValidationError("unexpected baseline product")
        classification=item["classification"]
        reg.register_product({"product_id":pid,"display_name":name,"current_release_id":None,"classification":classification},actor=actor)
        rid=f"{pid}-{NORMALIZED[item['version']].replace('.','_')}"
        reg.register_release({
            "release_id":rid,"product_id":pid,"version":item["version"],"semantic_version":NORMALIZED[item["version"]],
            "artifact_filename":item["artifact_filename"],"sha256":item["sha256"],"artifact_size":item["artifact_size"],
            "verification_state":item["verification_state"],"evidence_references":item["evidence_references"],
            "source_provenance":item["source_provenance"],"classification":classification,"release_state":classification
        },actor=actor)
    return reg.verify()
