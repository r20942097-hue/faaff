from __future__ import annotations

from pathlib import Path

from .evidence import EvidenceStore
from .io import sha256_file
from .registry import RegistryStore
from .validation import ValidationError

STATUSES={"PASS","FAIL","NOT_RUN","UNKNOWN"}

def _result(status,detail): return {"status":status,"detail":detail}

def audit(root:Path)->dict:
    root=Path(root); reg=RegistryStore(root); out={"Product":None,"Release":None,"Artifact":None,"Evidence":None,"Evidence Chain":None,"Capability":None,"Event Log":None,"Snapshot":None}
    try:
        state=reg.verify(); out["Product"]=_result("PASS",f"{len(state['products'])} products valid"); out["Release"]=_result("PASS",f"{len(state['releases'])} releases valid"); out["Capability"]=_result("PASS",f"{len(state['capabilities'])} capabilities valid")
    except Exception as exc:
        state=None; out["Product"]=out["Release"]=out["Capability"]=_result("FAIL",str(exc))
    if state is not None:
        artifacts_dir=root/"artifacts"; checked=0; missing=0
        for r in state["releases"].values():
            p=artifacts_dir/r["artifact_filename"]
            if not p.exists(): missing+=1; continue
            try:
                h,n=sha256_file(p)
                if h!=r["sha256"] or n!=r["artifact_size"]: raise ValidationError("artifact hash/size mismatch")
                checked+=1
            except Exception as exc:
                out["Artifact"]=_result("FAIL",f"{r['release_id']}: {exc}"); break
        if out["Artifact"] is None:
            out["Artifact"]=_result("PASS",f"{checked} local artifacts verified") if missing==0 else _result("NOT_RUN",f"{missing} baseline artifacts are external/not present locally; {checked} local verified")
    else: out["Artifact"]=_result("UNKNOWN","registry invalid")
    try:
        ids=EvidenceStore(root,reg).verify_all(); out["Evidence"]=_result("PASS",f"{len(ids)} evidence payloads valid"); out["Evidence Chain"]=_result("PASS",f"{len(ids)} evidence nodes acyclic and linked")
    except Exception as exc:
        out["Evidence"]=_result("FAIL",str(exc)); out["Evidence Chain"]=_result("FAIL",str(exc))
    try: ev=reg.events.verify(); out["Event Log"]=_result("PASS",f"{len(ev)} append-only chained events valid")
    except Exception as exc: out["Event Log"]=_result("FAIL",str(exc))
    try: snaps=reg.snapshots.verify_all(); out["Snapshot"]=_result("PASS",f"{len(snaps)} snapshots valid") if snaps else _result("NOT_RUN","no snapshots")
    except Exception as exc: out["Snapshot"]=_result("FAIL",str(exc))
    overall="FAIL" if any(v["status"]=="FAIL" for v in out.values()) else ("UNKNOWN" if any(v["status"]=="UNKNOWN" for v in out.values()) else ("NOT_RUN" if any(v["status"]=="NOT_RUN" for v in out.values()) else "PASS"))
    return {"overall":overall,"checks":out}
