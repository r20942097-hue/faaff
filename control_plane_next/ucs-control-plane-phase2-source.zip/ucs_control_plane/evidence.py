from __future__ import annotations

import os
from pathlib import Path

from .io import atomic_write_bytes, sha256_bytes
from .registry import RegistryStore
from .validation import (
    ValidationError, canonical_json_bytes, ensure_canonical_json_payload, ensure_regular_file_no_links,
    now_rfc3339, strict_json_loads, validate_rfc3339, validate_safe_id, validate_semver
)

META_FIELDS={"schema_version","evidence_id","evidence_type","lifecycle","payload_filename","sha256","payload_size","created_at","registered_at","sealed_at","parent_evidence","supersedes"}

class EvidenceStore:
    def __init__(self, root:Path, registry:RegistryStore|None=None):
        self.root=Path(root); self.registry=registry or RegistryStore(root); self.meta_dir=self.root/"evidence"/"meta"; self.payload_dir=self.root/"evidence"/"payloads"
    def _meta_path(self,eid): return self.meta_dir/f"{eid}.json"
    def _payload_path(self,eid): return self.payload_dir/f"{eid}.payload"
    def _load_meta(self,eid):
        validate_safe_id(eid,"evidence_id"); p=self._meta_path(eid); ensure_regular_file_no_links(p,self.root)
        meta=strict_json_loads(p.read_bytes()); self._validate_meta(meta); return meta
    @staticmethod
    def _validate_meta(meta:dict):
        if not isinstance(meta,dict) or set(meta)!=META_FIELDS: raise ValidationError("evidence metadata fields mismatch")
        validate_semver(meta["schema_version"]); validate_safe_id(meta["evidence_id"],"evidence_id")
        if meta["evidence_type"] not in {"JSON","TEXT","BINARY"} or meta["lifecycle"] not in {"DRAFT","REGISTERED","SEALED"}: raise ValidationError("invalid evidence metadata enum")
        if meta["payload_filename"]!=f"{meta['evidence_id']}.payload": raise ValidationError("payload filename mismatch")
        if not isinstance(meta["sha256"],str) or len(meta["sha256"])!=64: raise ValidationError("invalid evidence sha")
        if type(meta["payload_size"]) is not int or meta["payload_size"]<0: raise ValidationError("invalid payload size")
        validate_rfc3339(meta["created_at"])
        for k in ("registered_at","sealed_at"):
            if meta[k] is not None: validate_rfc3339(meta[k])
        for k in ("parent_evidence","supersedes"):
            if meta[k] is not None: validate_safe_id(meta[k],k)
    def create_draft(self,evidence_id:str,payload:bytes,*,evidence_type:str,parent_evidence=None,supersedes=None):
        validate_safe_id(evidence_id,"evidence_id")
        if evidence_type not in {"JSON","TEXT","BINARY"}: raise ValidationError("invalid evidence type")
        if self._meta_path(evidence_id).exists() or self._payload_path(evidence_id).exists(): raise ValidationError("duplicate evidence ID")
        if len(payload)>16*1024*1024: raise ValidationError("evidence payload exceeds bound")
        if evidence_type=="JSON": ensure_canonical_json_payload(payload)
        elif evidence_type=="TEXT": payload.decode("utf-8")
        for link in (parent_evidence,supersedes):
            if link is not None: validate_safe_id(link,"evidence link")
        self.payload_dir.mkdir(parents=True,exist_ok=True); self.meta_dir.mkdir(parents=True,exist_ok=True)
        atomic_write_bytes(self._payload_path(evidence_id),payload)
        meta={"schema_version":"1.0.0","evidence_id":evidence_id,"evidence_type":evidence_type,"lifecycle":"DRAFT","payload_filename":f"{evidence_id}.payload","sha256":sha256_bytes(payload),"payload_size":len(payload),"created_at":now_rfc3339(),"registered_at":None,"sealed_at":None,"parent_evidence":parent_evidence,"supersedes":supersedes}
        atomic_write_bytes(self._meta_path(evidence_id),canonical_json_bytes(meta)); return meta
    def _verify_payload(self,meta):
        p=self._payload_path(meta["evidence_id"]); ensure_regular_file_no_links(p,self.root); data=p.read_bytes()
        if len(data)!=meta["payload_size"] or sha256_bytes(data)!=meta["sha256"]: raise ValidationError("evidence payload hash/size mismatch")
        if meta["evidence_type"]=="JSON": ensure_canonical_json_payload(data)
        elif meta["evidence_type"]=="TEXT": data.decode("utf-8")
        return data
    def register(self,eid:str,*,actor="operator"):
        meta=self._load_meta(eid)
        if meta["lifecycle"]!="DRAFT": raise ValidationError("evidence must be DRAFT")
        self._verify_payload(meta)
        current=self.registry.verify()["evidence"]
        for link_name in ("parent_evidence","supersedes"):
            target=meta[link_name]
            if target is not None and target not in current: raise ValidationError("broken evidence chain")
            if target == eid: raise ValidationError("evidence cycle")
        meta["lifecycle"]="REGISTERED"; meta["registered_at"]=now_rfc3339(); atomic_write_bytes(self._meta_path(eid),canonical_json_bytes(meta))
        idx={"evidence_id":eid,"state":"REGISTERED","sha256":meta["sha256"],"payload_size":meta["payload_size"],"evidence_type":meta["evidence_type"],"parent_evidence":meta["parent_evidence"],"supersedes":meta["supersedes"]}
        self.registry.upsert_evidence_index(idx,event_type="EVIDENCE_REGISTERED",actor=actor,previous_state="DRAFT",new_state="REGISTERED"); return meta
    def seal(self,eid:str,*,actor="operator"):
        meta=self._load_meta(eid)
        if meta["lifecycle"]!="REGISTERED": raise ValidationError("evidence must be REGISTERED")
        self._verify_payload(meta); meta["lifecycle"]="SEALED"; meta["sealed_at"]=now_rfc3339(); atomic_write_bytes(self._meta_path(eid),canonical_json_bytes(meta),mode=0o444)
        if os.name!="nt": self._meta_path(eid).chmod(0o444); self._payload_path(eid).chmod(0o444)
        idx={"evidence_id":eid,"state":"SEALED","sha256":meta["sha256"],"payload_size":meta["payload_size"],"evidence_type":meta["evidence_type"],"parent_evidence":meta["parent_evidence"],"supersedes":meta["supersedes"]}
        self.registry.upsert_evidence_index(idx,event_type="EVIDENCE_SEALED",actor=actor,previous_state="REGISTERED",new_state="SEALED"); return meta
    def archive(self,eid:str,*,actor="operator"):
        meta=self._load_meta(eid)
        if meta["lifecycle"]!="SEALED": raise ValidationError("only sealed evidence can be archived")
        idx={"evidence_id":eid,"state":"ARCHIVED","sha256":meta["sha256"],"payload_size":meta["payload_size"],"evidence_type":meta["evidence_type"],"parent_evidence":meta["parent_evidence"],"supersedes":meta["supersedes"]}
        self.registry.upsert_evidence_index(idx,event_type="EVIDENCE_ARCHIVED",actor=actor,previous_state="SEALED",new_state="ARCHIVED"); return idx
    def verify_one(self,eid:str):
        meta=self._load_meta(eid); self._verify_payload(meta); state=self.registry.verify(); idx=state["evidence"].get(eid)
        if meta["lifecycle"]=="DRAFT":
            if idx is not None: raise ValidationError("draft evidence unexpectedly indexed")
        else:
            if idx is None: raise ValidationError("registered evidence missing from registry")
            allowed={meta["lifecycle"]} if meta["lifecycle"]!="SEALED" else {"SEALED","ARCHIVED"}
            if (idx["state"] not in allowed or idx["sha256"]!=meta["sha256"] or idx["payload_size"]!=meta["payload_size"] or
                    idx["evidence_type"]!=meta["evidence_type"] or idx["parent_evidence"]!=meta["parent_evidence"] or idx["supersedes"]!=meta["supersedes"]):
                raise ValidationError("evidence registry mismatch")
        return meta
    def verify_all(self)->list[str]:
        if not self.meta_dir.exists(): return []
        ids=[]
        for p in sorted(self.meta_dir.glob("*.json")):
            if p.is_symlink(): raise ValidationError("evidence metadata symlink rejected")
            eid=p.stem; self.verify_one(eid); ids.append(eid)
        state=self.registry.verify(); graph={eid:[] for eid in state["evidence"]}
        for eid,rec in state["evidence"].items():
            for k in ("parent_evidence","supersedes"):
                target=rec[k]
                if target is not None:
                    if target not in state["evidence"]: raise ValidationError("broken evidence chain")
                    graph[eid].append(target)
        visiting=set(); done=set()
        def dfs(node):
            if node in visiting: raise ValidationError("evidence cycle")
            if node in done: return
            visiting.add(node)
            for nxt in graph[node]: dfs(nxt)
            visiting.remove(node); done.add(node)
        for n in graph: dfs(n)
        return ids
